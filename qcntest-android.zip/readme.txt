to install on device:

adb install SensorSimulatorSettings-2.0-rc1.apk

run on device just go to Android Apps and click


to run 'sensor simulator service' on host machine:

java -jar sensorsimulator-2.0-rc1.jar &


