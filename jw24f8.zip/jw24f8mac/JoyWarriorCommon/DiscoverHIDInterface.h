/*
 *  DiscoverDevice.h
 *  JoyWarrior Programmingtool
 *
 *  Created by ilja on 02.11.07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include <CoreFoundation/CoreFoundation.h>

CFMutableArrayRef DiscoverHIDInterfaces (int vendorID, int deviceID);
CFMutableArrayRef DiscoverHIDDeviceProperties (int vendorID, int deviceID);

void ReleaseInterfaces (CFMutableArrayRef inInterfaces);
int AddUSBDeviceAddedCallback (int vendorID, int deviceID, IOServiceMatchingCallback inCallback);
int AddUSBDevicRemovedCallback (int vendorID, int deviceID, IOServiceMatchingCallback inCallback);
