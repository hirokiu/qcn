/*
 *  DiscoverDevice.c
 *  JoyWarrior Programmingtool
 *
 *  Created by ilja on 02.11.07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/hid/IOHIDLib.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>

CFMutableDictionaryRef SetUpHIDMatchingDictionary (int inVendorID, int inDeviceID)
{
	CFMutableDictionaryRef 	refHIDMatchDictionary = NULL;
	
    // Set up a matching dictionary to search I/O Registry by class name for all IOWarrior devices.
    refHIDMatchDictionary = IOServiceMatching (kIOHIDDeviceKey);
    if (refHIDMatchDictionary != NULL)
    {
		CFNumberRef numberRef;
				
		numberRef = CFNumberCreate (kCFAllocatorDefault, kCFNumberIntType, &inVendorID);
		CFDictionarySetValue (refHIDMatchDictionary, CFSTR (kIOHIDVendorIDKey), numberRef);
		CFRelease (numberRef);

		numberRef = CFNumberCreate (kCFAllocatorDefault, kCFNumberIntType, &inDeviceID);
		CFDictionarySetValue (refHIDMatchDictionary, CFSTR (kIOHIDProductIDKey), numberRef);
		CFRelease (numberRef);

    }
    else
        CFLog ("Failed to get HID CFMutableDictionaryRef via IOServiceMatching.");
    return refHIDMatchDictionary;
}


/* Returns an iterator object, which can be used to iterate through all hid devices available on the machine. You have to release the iterator after usage be calling IOObjectRelease (hidObjectIterator).*/
io_iterator_t FindHIDDevices (const mach_port_t masterPort, int inVendorID, int inDeviceID)
{
    CFMutableDictionaryRef	hidMatchDictionary = NULL;
    IOReturn				ioReturnValue = kIOReturnSuccess;
    io_iterator_t			hidObjectIterator;
	
    // Set up matching dictionary to search the I/O Registry for HID devices we are interested in. Dictionary reference is NULL if error.
    hidMatchDictionary = SetUpHIDMatchingDictionary (inVendorID, inDeviceID);
    if (NULL == hidMatchDictionary)
    {
        CFShow (CFSTR("Couldn't create a matching dictionary."));
        return nil;
    }
	
    // Now search I/O Registry for matching devices.
    ioReturnValue = IOServiceGetMatchingServices (masterPort, hidMatchDictionary, &hidObjectIterator);
    // If error, print message and hang (for debugging purposes).
    if ((ioReturnValue != kIOReturnSuccess) | (hidObjectIterator == nil))
    {
        return nil;
    }
	
    // IOServiceGetMatchingServices consumes a reference to the dictionary, so we don't need to release the dictionary ref.
    hidMatchDictionary = NULL;
	
    return hidObjectIterator;
}

IOHIDDeviceInterface122 ** CreateHIDDeviceInterface (io_object_t hidDevice)
{
    io_name_t						className;
    IOCFPlugInInterface**			plugInInterface = NULL;
    HRESULT							plugInResult = S_OK;
    SInt32							score = 0;
    IOReturn						ioReturnValue = kIOReturnSuccess;
    IOHIDDeviceInterface122**		pphidDeviceInterface = NULL;
	
    ioReturnValue = IOObjectGetClass (hidDevice, className);
	if (ioReturnValue)
	{
		CFShow (CFSTR ("Failed to get class name."));
	}
    ioReturnValue = IOCreatePlugInInterfaceForService (hidDevice, 
													   kIOHIDDeviceUserClientTypeID,
                                                       kIOCFPlugInInterfaceID, 
													   &plugInInterface, 
													   &score);
    if (ioReturnValue == kIOReturnSuccess)
    {
        // Call a method of the intermediate plug-in to create the device interface
        plugInResult = (*plugInInterface)->QueryInterface (plugInInterface,
                                                           CFUUIDGetUUIDBytes (kIOHIDDeviceInterfaceID122),
														   (void *) &pphidDeviceInterface);
        if (plugInResult != S_OK)
            CFShow (CFSTR ("Couldn't query HID class device interface from plugInInterface"));
        (*plugInInterface)->Release (plugInInterface);
    }
    else
        CFShow (CFSTR ("Failed to create **plugInInterface via IOCreatePlugInInterfaceForService."));
    return pphidDeviceInterface;
}

CFMutableArrayRef DiscoverHIDInterfaces (int vendorID, int deviceID)
{
	mach_port_t					masterPort = nil;
	io_iterator_t					hidObjectIterator = nil;
	IOReturn						ioReturnValue;
	CFMutableArrayRef				result = CFArrayCreateMutable(kCFAllocatorDefault,0,nil);

	ioReturnValue = IOMasterPort (bootstrap_port, &masterPort);
	if(ioReturnValue != kIOReturnSuccess)
	{
		CFShow (CFSTR ("Couldn't create a master I/O Kit Port."));
		return result;
	}
	hidObjectIterator = FindHIDDevices (masterPort, vendorID, deviceID); 
	if (hidObjectIterator != nil)
	{
		io_object_t 	hidDevice = nil;
		IOReturn		ioReturnValue = kIOReturnSuccess;
		
		
		while ((hidDevice = IOIteratorNext (hidObjectIterator)))
		{
			kern_return_t				err;
			CFMutableDictionaryRef		properties = 0;
			IOHIDDeviceInterface122		**hidInterface;
			CFNumberRef					hidInterfaceRef;
			
			err = IORegistryEntryCreateCFProperties (hidDevice, &properties, kCFAllocatorDefault, kNilOptions);
			hidInterface = CreateHIDDeviceInterface (hidDevice);
			
			hidInterfaceRef = CFNumberCreate(kCFAllocatorDefault,kCFNumberLongType,&hidInterface);
				
			CFArrayAppendValue(result,hidInterfaceRef);
			CFRelease (properties);
			ioReturnValue = IOObjectRelease (hidDevice);
		}
	}
	IOObjectRelease (hidObjectIterator);

	mach_port_deallocate (mach_task_self (), masterPort);
	
	return result;
}

CFMutableArrayRef DiscoverHIDDeviceProperties (int vendorID, int deviceID)
{
	mach_port_t					masterPort = nil;
	io_iterator_t					hidObjectIterator = nil;
	IOReturn						ioReturnValue;
	CFMutableArrayRef				result = CFArrayCreateMutable(kCFAllocatorDefault,0,nil);
	
	ioReturnValue = IOMasterPort (bootstrap_port, &masterPort);
	if(ioReturnValue != kIOReturnSuccess)
	{
		CFShow (CFSTR ("Couldn't create a master I/O Kit Port."));
		return result;
	}
	hidObjectIterator = FindHIDDevices (masterPort, vendorID, deviceID); 
	if (hidObjectIterator != nil)
	{
		io_object_t 	hidDevice = nil;
		IOReturn		ioReturnValue = kIOReturnSuccess;
		
		while ((hidDevice = IOIteratorNext (hidObjectIterator)))
		{
			kern_return_t				err;
			CFMutableDictionaryRef		properties = 0;
			
			err = IORegistryEntryCreateCFProperties (hidDevice, &properties, kCFAllocatorDefault, kNilOptions);
			if (!err)
			{
				CFDictionaryRef				copy;

				copy = CFDictionaryCreateCopy(kCFAllocatorDefault,properties);
				CFArrayAppendValue(result,copy);
				//CFRelease (copy); // it seems the array does not correctly retain the dictionary, so releasing it here doesn't work
			}
			CFRelease (properties);
			ioReturnValue = IOObjectRelease (hidDevice);
		}
	}
	IOObjectRelease (hidObjectIterator);
	
	mach_port_deallocate (mach_task_self (), masterPort);
	
	return result;
}

void ReleaseInterfaces (CFMutableArrayRef inInterfaces)
{
	CFIndex	i = 0;
	CFIndex limit = CFArrayGetCount(inInterfaces);
	
	for (i = 0; i < limit; i++)
	{
		IOHIDDeviceInterface122		**interface;
		CFNumberRef					hidInterfaceRef;
		
		hidInterfaceRef = CFArrayGetValueAtIndex(inInterfaces,i);
		CFNumberGetValue(hidInterfaceRef,kCFNumberLongType,&interface);
		(*interface)->Release(interface);
	}
	
}


int AddUSBDevicRemovedCallback (int vendorID, int deviceID, IOServiceMatchingCallback inCallback )
{
	int						result;
	mach_port_t				masterPort = nil;
	CFNumberRef				temp;
	IONotificationPortRef	notifyPort;
	io_iterator_t			notificationIterator;
	io_service_t            usbDevice;
	CFRunLoopSourceRef      runLoopSource;
	CFMutableDictionaryRef  matchingDict;
	
	//Create a master port for communication with the I/O Kit
    result = IOMasterPort(MACH_PORT_NULL, &masterPort);
    if (result || !masterPort)
    {
        return -1;
    }
	notifyPort = IONotificationPortCreate(masterPort);
    runLoopSource = IONotificationPortGetRunLoopSource(notifyPort);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource, kCFRunLoopDefaultMode);
    
	//Set up matching dictionary for class IOUSBDevice and its subclasses
    matchingDict = IOServiceMatching(kIOUSBDeviceClassName);
    if (!matchingDict)
    {
        mach_port_deallocate(mach_task_self(), masterPort);
        return -1;
    }
	
    //Add the vendor and product IDs to the matching dictionary
    //This is the second key of the first table in the USB Common Class
    //Specification
	temp =  CFNumberCreate (kCFAllocatorDefault, kCFNumberSInt32Type, &vendorID);
    CFDictionarySetValue(matchingDict, CFSTR(kUSBVendorName),temp);
	CFRelease (temp);
	temp =  CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &deviceID);
    CFDictionarySetValue(matchingDict, CFSTR(kUSBProductName),temp);
	CFRelease (temp);
	
	result = IOServiceAddMatchingNotification(notifyPort, kIOTerminatedNotification, matchingDict,
                                              inCallback, NULL, &notificationIterator);
	// notification is armed by emptying iterator
    while (usbDevice = IOIteratorNext(notificationIterator))
    {
        IOObjectRelease(usbDevice);
    }
	
	//Finished with master port
    mach_port_deallocate(mach_task_self(), masterPort);
	
    return result;
	
}

int AddUSBDeviceAddedCallback (int vendorID, int deviceID, IOServiceMatchingCallback inCallback )
{
	int						result;
	mach_port_t				masterPort = nil;
	CFNumberRef				temp;
	IONotificationPortRef	notifyPort;
	io_iterator_t			notificationIterator;
	io_service_t            usbDevice;
	CFRunLoopSourceRef      runLoopSource;
	CFMutableDictionaryRef  matchingDict;

	//Create a master port for communication with the I/O Kit
    result = IOMasterPort(MACH_PORT_NULL, &masterPort);
    if (result || !masterPort)
    {
        return -1;
    }
	notifyPort = IONotificationPortCreate(masterPort);
    runLoopSource = IONotificationPortGetRunLoopSource(notifyPort);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource, kCFRunLoopDefaultMode);
    
	//Set up matching dictionary for class IOUSBDevice and its subclasses
    matchingDict = IOServiceMatching(kIOUSBDeviceClassName);
    if (!matchingDict)
    {
        mach_port_deallocate(mach_task_self(), masterPort);
        return -1;
    }
	
    //Add the vendor and product IDs to the matching dictionary
    //This is the second key of the first table in the USB Common Class
    //Specification
	temp =  CFNumberCreate (kCFAllocatorDefault, kCFNumberSInt32Type, &vendorID);
    CFDictionarySetValue(matchingDict, CFSTR(kUSBVendorName),temp);
	CFRelease (temp);
	temp =  CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &deviceID);
    CFDictionarySetValue(matchingDict, CFSTR(kUSBProductName),temp);
	CFRelease (temp);
	
	result = IOServiceAddMatchingNotification(notifyPort, kIOFirstMatchNotification, matchingDict,
                                              inCallback, NULL, &notificationIterator);
	// notification is armed by emptying iterator
    while (usbDevice = IOIteratorNext(notificationIterator))
    {
        IOObjectRelease(usbDevice);
    }
	
	//Finished with master port
    mach_port_deallocate(mach_task_self(), masterPort);
	
    return result;
}
