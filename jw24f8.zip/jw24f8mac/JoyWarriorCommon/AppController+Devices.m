//
//  AppController+Devices.m
//  JoyWarrior Tilt Utility
//
//  Created by ilja on 19.02.08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AppController+Devices.h"
#import "DiscoverHIDInterface.h"

@implementation AppController (Devices)

- (CFMutableArrayRef) discoverInterfaces
{
	CFMutableArrayRef interfaces;
	
	// JoyWarrior24 Force 8
	interfaces = DiscoverHIDInterfaces	(0x07c0, 0x1113);
	if (CFArrayGetCount (interfaces) >= 2)
		return interfaces;
	
	if (interfaces)
		CFRelease (interfaces);
	// MouseWarrior25 Force 6
	
	interfaces = DiscoverHIDInterfaces	(0x07c0, 0x1114);
	if (CFArrayGetCount (interfaces) >= 2)
		return interfaces;
	
	CFRelease (interfaces);
	return nil;
}

- (CFMutableArrayRef) discoverDeviceProperties
{
	CFMutableArrayRef deviceProperties;
	
	// JoyWarrior24 Force 8
	deviceProperties = DiscoverHIDDeviceProperties	(0x07c0, 0x1113);
	if (CFArrayGetCount (deviceProperties))
		return deviceProperties;
	
	if (deviceProperties)
		CFRelease (deviceProperties);
	
	// MouseWarrior25 Force 6
	deviceProperties = DiscoverHIDDeviceProperties (0x07c0, 0x1114);
	if (CFArrayGetCount (deviceProperties))
		return deviceProperties;
	
	CFRelease (deviceProperties);
	return nil;
}


@end
