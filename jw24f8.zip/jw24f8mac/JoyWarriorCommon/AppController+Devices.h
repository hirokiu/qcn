//
//  AppController+Devices.h
//  JoyWarrior Tilt Utility
//
//  Created by ilja on 19.02.08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "AppController.h"

@interface AppController (Devices) 


- (CFMutableArrayRef) discoverInterfaces;
- (CFMutableArrayRef) discoverDeviceProperties;


@end
