#import <Cocoa/Cocoa.h>

@class IOHIDDeviceInterface122;

@interface AppController : NSObject /* Specify a superclass (eg: NSObject or NSView) */ {

	IBOutlet NSTextField	*deviceTypeField;
	IBOutlet NSTextField	*deviceSerialField;
	
	IOHIDDeviceInterface122**	interface;
	
	NSTimer	*readTimer;
	
	NSString	*xAxis;
	NSString	*yAxis;
	NSString	*zAxis;
	
	NSString	*xOffset;
	NSString	*yOffset;
	NSString	*zOffset;
	
	NSString	*xOffsetHex;
	NSString	*yOffsetHex;
	NSString	*zOffsetHex;
}

- (IBAction) calibrateButtonClicked:(id) sender;

- (void) writeOffset:(NSString*) inAxis;

- (void) updateDeviceState;
- (void) readOffsetValues;

- (NSString *) xAxis;
- (void) setXAxis: (NSString *) inXAxis;

- (NSString *) yAxis;
- (void) setYAxis: (NSString *) inYAxis;

- (NSString *) zAxis;
- (void) setZAxis: (NSString *) inZAxis;

- (NSString *) xOffset;
- (void) setXOffset: (NSString *) inXOffset;

- (NSString *) yOffset;
- (void) setYOffset: (NSString *) inYOffset;

- (NSString *) zOffset;
- (void) setZOffset: (NSString *) inZOffset;

- (NSString *) xOffsetHex;
- (void) setXOffsetHex: (NSString *) inXOffsetHex;

- (NSString *) yOffsetHex;
- (void) setYOffsetHex: (NSString *) inYOffsetHex;

- (NSString *) zOffsetHex;
- (void) setZOffsetHex: (NSString *) inZOffsetHex;



@end
