#import "AppController.h"
#import "AppController+Devices.h"
#import "DiscoverHIDInterface.h"
#import <IOKit/hid/IOHIDLib.h>

@implementation AppController

void JoyWarriorAddedOrRemoved(void *refCon, io_iterator_t iterator)
{
    io_service_t            usbDevice;
    
    while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
    }
	[[NSApp delegate] updateDeviceState];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

- (void) dealloc
{
    [self setXAxis: nil];
    [self setYAxis: nil];
    [self setZAxis: nil];
	
	[self setXOffset: nil];
    [self setYOffset: nil];
    [self setZOffset: nil];
	
	[self setXOffsetHex: nil];
    [self setYOffsetHex: nil];
    [self setZOffsetHex: nil];
	
    [super dealloc];
}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{	
	AddUSBDeviceAddedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	
	AddUSBDeviceAddedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	
	[self updateDeviceState];
	
}

- (void) updateDeviceState
{
	CFMutableArrayRef interfaces;
	
	interfaces = [self discoverInterfaces];
	if ((nil != interfaces) && (CFArrayGetCount (interfaces) >= 2))
	{
		CFMutableArrayRef deviceProperties;
		CFNumberRef			interfaceRef;
		
		interfaceRef =	CFArrayGetValueAtIndex(interfaces,1);
		CFNumberGetValue(interfaceRef,kCFNumberLongType,&interface);
		
		deviceProperties = [self discoverDeviceProperties];
		
		if ( CFArrayGetCount (deviceProperties))
		{
			CFDictionaryRef	  properties = CFArrayGetValueAtIndex(deviceProperties, 0);
			[deviceTypeField setStringValue:[(NSDictionary*) properties valueForKey:@"Product"]]; 
			[deviceSerialField setStringValue:[(NSDictionary*) properties valueForKey:@"SerialNumber"]];
		}
		
		CFRelease (deviceProperties);
		
		[self readOffsetValues];
		
		readTimer = [NSTimer scheduledTimerWithTimeInterval:0.2
													 target:self
												   selector:@selector (readAxisValuesTimed:)
												   userInfo:nil
													repeats:YES];
	}
	else
	{
		interface = 0;
		
		[readTimer invalidate];
		readTimer = nil;
		
		[deviceSerialField setStringValue:@""];
		[deviceTypeField setStringValue:@""];
		
	}
	if (interfaces)
		CFRelease (interfaces);
}

- (void) readOffsetValues
{
	UInt8						rawData[7];
	UInt8						temp;
	int							i;
	SInt16						x, y, z;

	// open eprom 
	JWReadByteFromAddress (interface, 0xA, &temp);
	temp = temp | 0x10;
	JWWriteByteToAddress (interface, 0xA, temp);

	for (i = 0; i < 7; i++)
	{
		JWReadByteFromAddress (interface, 0x16 + i, &rawData[i]);
	}
	
	x = JWMergeOffsetBytes(rawData[0], rawData[4]);
	y = JWMergeOffsetBytes(rawData[1], rawData[5]);
	z = JWMergeOffsetBytes(rawData[2], rawData[6]);
	
	[self setXOffset:[NSString stringWithFormat:@"%d", x]];
	[self setYOffset:[NSString stringWithFormat:@"%d", y]];
	[self setZOffset:[NSString stringWithFormat:@"%d", z]];
	
	[self setXOffsetHex:[NSString stringWithFormat:@"0x%03X", x]];
	[self setYOffsetHex:[NSString stringWithFormat:@"0x%03X", y]];
	[self setZOffsetHex:[NSString stringWithFormat:@"0x%03X", z]];
}

- (void) readAxisValuesTimed:(NSTimer*) inTimer
{
	if (interface)
	{
		UInt8						rawData[6];
		int							i;
		SInt16						x, y, z;

		for (i = 0; i < 6; i++)
		{
			JWReadByteFromAddress (interface, 0x02 + i, &rawData[i]);
		}
		x = JWMergeAxisBytes(rawData[0], rawData[1]);
		y = JWMergeAxisBytes(rawData[2], rawData[3]);
		z = JWMergeAxisBytes(rawData[4], rawData[5]);
		
		[self setXAxis:[NSString stringWithFormat:@"%d", x]];
		[self setYAxis:[NSString stringWithFormat:@"%d", y]];
		[self setZAxis:[NSString stringWithFormat:@"%d", z]];
	}
}


- (NSString *) xAxis
{
    return xAxis; 
}

- (void) setXAxis: (NSString *) inXAxis
{
    if (xAxis != inXAxis) {
        [xAxis autorelease];
        xAxis = [inXAxis retain];
    }
}


- (NSString *) yAxis
{
    return yAxis; 
}

- (void) setYAxis: (NSString *) inYAxis
{
    if (yAxis != inYAxis) {
        [yAxis autorelease];
        yAxis = [inYAxis retain];
    }
}


- (NSString *) zAxis
{
    return zAxis; 
}

- (void) setZAxis: (NSString *) inZAxis
{
    if (zAxis != inZAxis) {
        [zAxis autorelease];
        zAxis = [inZAxis retain];
    }
}

- (NSString *) xOffset
{
    return xOffset; 
}

- (void) setXOffset: (NSString *) inXOffset
{
    if (xOffset != inXOffset) {
        [xOffset autorelease];
        xOffset = [inXOffset retain];
    }
}


- (NSString *) yOffset
{
    return yOffset; 
}

- (void) setYOffset: (NSString *) inYOffset
{
    if (yOffset != inYOffset) {
        [yOffset autorelease];
        yOffset = [inYOffset retain];
    }
}


- (NSString *) zOffset
{
    return zOffset; 
}

- (void) setZOffset: (NSString *) inZOffset
{
    if (zOffset != inZOffset) {
        [zOffset autorelease];
        zOffset = [inZOffset retain];
    }
}

- (NSString *) xOffsetHex
{
    return xOffsetHex; 
}

- (void) setXOffsetHex: (NSString *) inXOffsetHex
{
    if (xOffsetHex != inXOffsetHex) {
        [xOffsetHex autorelease];
        xOffsetHex = [inXOffsetHex retain];
    }
}


- (NSString *) yOffsetHex
{
    return yOffsetHex; 
}

- (void) setYOffsetHex: (NSString *) inYOffsetHex
{
    if (yOffsetHex != inYOffsetHex) {
        [yOffsetHex autorelease];
        yOffsetHex = [inYOffsetHex retain];
    }
}


- (NSString *) zOffsetHex
{
    return zOffsetHex; 
}

- (void) setZOffsetHex: (NSString *) inZOffsetHex
{
    if (zOffsetHex != inZOffsetHex) {
        [zOffsetHex autorelease];
        zOffsetHex = [inZOffsetHex retain];
    }
}


- (IBAction) calibrateButtonClicked:(id) sender
{
	int			response;
	UInt8		temp;

	response = NSRunAlertPanel (@"Calibration Warning",
					 @"Are you sure you want to calibrate the conencted device",
					 @"OK",
					 @"Cancel",
					 nil);
	
	if (response != NSAlertDefaultReturn)
		return;
	
	[readTimer invalidate];

	// open eprom 
	JWReadByteFromAddress (interface, 0xA, &temp);
	temp = temp | 0x10;
	JWWriteByteToAddress (interface, 0xA, temp);
	
	
	[self writeOffset:@"X"];
	[self writeOffset:@"Y"];
	[self writeOffset:@"Z"];

	// open eprom 
	JWReadByteFromAddress (interface, 0xA, &temp);
	temp = temp & 0xEF; 
	JWWriteByteToAddress (interface, 0xA, temp);
	
	readTimer = [NSTimer scheduledTimerWithTimeInterval:0.2
												 target:self
											   selector:@selector (readAxisValuesTimed:)
											   userInfo:nil
												repeats:YES];
	
}

- (void) writeOffset:(NSString*) inAxis
{
	UInt8 offset_lsb;
	UInt8 offset_msb;
	UInt8 set_offset;
	UInt8 acc_value_lsb;
	UInt8 acc_value_msb;
	
	UInt8 OFF_MSB, OFF_LSB, OFF_GAIN;
	
	UInt8 ACC_MSB, ACC_LSB;

	
	/*
	 For more detail of reference take  look into the datasheet (page 9)
	 Default for 2g is (0;0;256)	
	 */
	SInt16 reference_x[6] = {0,0,0,0,256,-256};
	SInt16 reference_y[6] = {0,0,256,-256,0,0};
	SInt16 reference_z[6] = {256,-256,0,0,0,0};
	
	SInt16 reference;
	SInt16 ref = 0;

	
	if ([inAxis isEqualToString:@"X"])
	{
		offset_lsb = 0x16;
		offset_msb = 0x1A;
		acc_value_lsb = 0x02;
		acc_value_msb = 0x03;
		reference = reference_x[0];
	}
	else if ([inAxis isEqualToString:@"Y"])
	{
		offset_lsb = 0x17;
		offset_msb = 0x1B;
		acc_value_lsb = 0x04;
		acc_value_msb = 0x05;
		reference = reference_y[0];
	}
	else if ([inAxis isEqualToString:@"Z"])
	{
		offset_lsb = 0x18;
		offset_msb = 0x1C;
		acc_value_lsb = 0x06;
		acc_value_msb = 0x07;
		reference = reference_z[0];
	}
	
	/*save GAIN*/

	JWReadByteFromAddress(interface, offset_lsb, &OFF_LSB);
	OFF_GAIN = OFF_LSB & 0x3F;
	

	do
	{
		SInt16 dif = 0;
		SInt16 off = 0;
		
		JWReadByteFromAddress(interface, acc_value_lsb, &ACC_LSB);
		JWReadByteFromAddress(interface, acc_value_msb, &ACC_MSB);

		dif = JWMergeAxisBytes(ACC_LSB, ACC_MSB); //get Acc -> double-wert
		
		JWReadByteFromAddress(interface, offset_lsb, &OFF_LSB);
		JWReadByteFromAddress(interface, offset_msb, &OFF_MSB);

		off = JWMergeAxisBytes(OFF_LSB, OFF_MSB); //get Offset -> double-wert
		
		/*division with 8 (for 2G & >25Hz*/
		ref = floor((dif - reference)/8.00);
		
		if ((dif > (reference + 4)) || (dif < (reference - 4)))  // is calibration needed?
		{
			UInt8 tempLSB, tempMSB;
			
			if((dif < 8) && (dif > 0)) //acc > +0 and < +8
				JWDiffMsbLsb (off -1, &tempLSB, &tempMSB);
			else if((dif > -8) && (dif < 0)) //acc < -0 and > -8
				JWDiffMsbLsb (off +1, &tempLSB, &tempMSB);
			else
				JWDiffMsbLsb (off - (short)ref, &tempLSB, &tempMSB);
			
			JWWriteByteToAddress(interface, offset_lsb | 0x00, tempLSB);
			JWWriteByteToAddress(interface, offset_msb | 0x00, tempMSB);
			
			usleep(50);
			
			/*write GAIN into LSB to restore old GAIN-Value*/
			JWReadByteFromAddress(interface, offset_lsb, &OFF_LSB);
			set_offset = OFF_LSB | OFF_GAIN;
			JWWriteByteToAddress(interface, offset_lsb | 0x00, set_offset);
			
			usleep(50); //Sleep because set register need short time to set
		}
		else
			break;
	}while(ref < 1);
	
	
	/*write offset from image -> eeprom*/
	
	OFF_LSB = 0;
	OFF_MSB = 0;
	
	JWReadByteFromAddress(interface, offset_lsb, &OFF_LSB);
	JWReadByteFromAddress(interface, offset_msb, &OFF_MSB);
	
	usleep(50);
	
	JWWriteByteToAddress(interface, offset_lsb | 0x20, OFF_LSB);

	usleep(50);
	
	JWWriteByteToAddress(interface, offset_msb | 0x20, OFF_MSB);

	usleep(200);
	
}

@end
