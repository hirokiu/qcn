#import "MyController.h"
#include <IOKit/hid/IOHIDUsageTables.h>
#import "ButtonView.h"
#import "AxisButtonView.h"

#include <IOKit/hid/IOHIDLib.h>
#include <IOKit/hid/IOHIDUsageTables.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>
#include <mach/mach.h>
#include <mach/mach_error.h>


#define kJoyWarrior24A8ID 4356
#define kJoyWarrior24A16ID 4357

#define kJoyWarrior24F8ID 4371

MyController					*gController;
static IONotificationPortRef    gNotifyPort;
static io_iterator_t            gJoyWarriorAddedIter;
static io_iterator_t            gJoyWarriorRemovedIter;
BOOL	gDeviceListDirty;

void JoyWarriorAdded(void *refCon, io_iterator_t iterator);

void JoyWarriorRemoved(void *refCon, io_iterator_t iterator);

@implementation MyController

- (void) awakeFromNib
{
	[self toggleButtonVisibilities];
	[self armUSBNotifications];
	
	[NSTimer scheduledTimerWithTimeInterval:1
									 target:self
								   selector:@selector (deviceListTimer:)
								   userInfo:nil
									repeats:YES];
	
	[self updateStatusField];
}

- (void) deviceListTimer:(NSTimer*) inTimer
{
	if (gDeviceListDirty)
	{
		gDeviceListDirty = NO;
		[self discoverDevice];
	}
}

- (IBAction)resetAction:(id)sender
{
	[self reset];
}

- (void) toggleButtonVisibilities
{
	int	minCookie = 3;
	int maxCookie = 10;
	int	i;
	BOOL state;
 
	// top row standard button and 
	for (i = minCookie; i <= maxCookie; i++)
	{
		state = (currentDeviceType != kDeviceTypeJoyWarriorA8);
		[[self buttonViewWithTag:i] setHidden:state];
	}
	
	// axis button 
	minCookie = 11;
	maxCookie = 13;
	
	for (i = minCookie; i <= maxCookie; i++)
	{
		state = !((currentDeviceType == kDeviceTypeJoyWarriorA8) ||
				(currentDeviceType == kDeviceTypeJoyWarriorA16));
		[[self buttonViewWithTag:i] setHidden:state];
	}
 
	// low row buttons
 
	minCookie = 103;
	maxCookie = 106;		
	for (i = minCookie; i <= maxCookie; i++)
	{
		state = (currentDeviceType != kDeviceTypeJoyWarriorA16);
		[[self buttonViewWithTag:i] setHidden:state];	
	}
	
	// up column buttons
	minCookie = 110;
	maxCookie = 118;
	for (i = minCookie; i <= maxCookie; i+= 4)
	{
		state = (currentDeviceType != kDeviceTypeJoyWarriorA16);
		[[self buttonViewWithTag:i] setHidden:state];	
	}
 
}


- (void) reset
{
	int	minCookie = 3;
	int maxCookie = 13;
	int	i;
	
	// top row standard button and axis button
	for (i = minCookie; i <= maxCookie; i++)
	{
		[(ButtonView*) [self buttonViewWithTag:i] resetState];
	}
	
	// low row buttons

	minCookie = 103;
	maxCookie = 106;		
	for (i = minCookie; i <= maxCookie; i++)
	{
			[(ButtonView*) [self buttonViewWithTag:i] resetState];	
	}
	
	// up column buttons
	minCookie = 110;
	maxCookie = 118;
	for (i = minCookie; i <= maxCookie; i+= 4)
	{
		[(ButtonView*) [self buttonViewWithTag:i] resetState];	
	}
	
	[self updateStatusField];
}

- (void) discoverDevice
{
	pRecDevice theDevice = NULL;
	int			type = kDeviceTypeNone;
	
	HIDBuildDeviceList (kHIDPage_GenericDesktop, kHIDUsage_GD_Joystick);
	
	if (theDevice = HIDGetFirstDevice())
	{
		do
		{
			if ((theDevice->vendorID == 1984)
				&& (theDevice->productID == kJoyWarrior24A8ID)) 
			{
				type = kDeviceTypeJoyWarriorA8;
				break;
			}
			else if ((theDevice->vendorID == 1984)
				&& (theDevice->productID == kJoyWarrior24A16ID)) 
			{
				type = kDeviceTypeJoyWarriorA16;
				break;
			}
			else if ((theDevice->vendorID == 1984)
					 && (theDevice->productID == kJoyWarrior24F8ID)) 
			{
				type = kDeviceTypeJoyWarriorF8;
				break;
			}
		}
		while (nil != (theDevice = HIDGetNextDevice (theDevice)));
	}		
	[self setDevice:theDevice ofType:type];
}

- (void) setDevice:(pRecDevice) inDevice ofType:(int) inDeviceType
{
	// check available elements	
	currentDeviceType = inDeviceType;
	device = inDevice;
	
	[eventTimer invalidate];
	eventTimer = nil;
	
	[self reset];
	
	if (inDevice)
	{
		// set callback for queue changes
		HIDQueueDevice(device);
		
		eventTimer = [NSTimer scheduledTimerWithTimeInterval:0.1
										 target:self
									   selector:@selector(timerSelector:)
									   userInfo:nil
										repeats:YES];
	}
	[self toggleButtonVisibilities];
	currentDeviceGood = NO;
}

- (void) timerSelector:(NSTimer*) inTimer
{
	IOHIDEventStruct theEvent;
	
	while (HIDGetEvent (device, &theEvent))
	{
		[self eventReceived:&theEvent];
	}
}

- (void) eventReceived:(IOHIDEventStruct*) inEvent
{
	ButtonView *theButton;
	int			buttonTag = (int) inEvent->elementCookie;

	// button event
	if (kIOHIDElementTypeInput_Button == inEvent->type)
	{
		
		if (currentDeviceType == kDeviceTypeJoyWarriorA16)
			buttonTag += 100;
		
		theButton = (ButtonView*) [self buttonViewWithTag:buttonTag];

		if (([theButton buttonState] == kButtonStatePressed) &&
			(inEvent->value == 0)) // keyup
		{
			[theButton setButtonState:kButtonStateTested];
		}
		else if (inEvent->value == 1) // keydown
		{
			[theButton setButtonState:kButtonStatePressed];
		}
		else
			[theButton setButtonState:kButtonStateUntested];
	}
	else if (kIOHIDElementTypeInput_Misc == inEvent->type)
	{
		if (currentDeviceType == kDeviceTypeJoyWarriorA16)
			buttonTag -= 8;
		
		AxisButtonView *axisButton = (AxisButtonView*) [self buttonViewWithTag:buttonTag];
		
		//NSLog (@"misc event received with value %d and cookie %d", inEvent->value, (int) inEvent->elementCookie);
		[axisButton setLastValue:inEvent->value];
		
		if (([axisButton minValue] == 0) 
			&& ([axisButton maxValue] == 255))
			[axisButton setButtonState:kButtonStateTested];
		else
			[axisButton setButtonState:kButtonStatePressed];
	}
	[self updateStatusField];
	if (!currentDeviceGood && [self currentDevicePassedTest])
	{
		currentDeviceGood = YES;
		[self incrementDeviceCounter];
	}
}

- (NSView*) buttonViewWithTag:(int) inTag
{
	NSEnumerator	*e = [[mainWindowContentView subviews] objectEnumerator];
	NSView			*buttonView;
	
	while (nil != (buttonView = [e nextObject]))
	{
		if([buttonView tag]== inTag)
		{
			return buttonView;
		}
	}
	return nil;
}

- (void) updateStatusField
{
	if (currentDeviceType == kDeviceTypeJoyWarriorA8)
	{
		if ([self currentDevicePassedTest])
		{
			[statusField setStringValue:@"JW24MOD-A8-8 OK"];
		}
		else
		{
			[statusField setStringValue:@"JW24MOD-A8-8 gefunden"];
		}
	}
	else if (currentDeviceType == kDeviceTypeJoyWarriorA16)
	{
		if ([self currentDevicePassedTest])
		{
			[statusField setStringValue:@"JW24MOD-A8-16 OK"];
		}
		else
		{
			[statusField setStringValue:@"JW24MOD-A8-16 gefunden"];
		}
	}
	else if (currentDeviceType == kDeviceTypeJoyWarriorF8)
	{
		if ([self currentDevicePassedTest])
		{
			[statusField setStringValue:@"JW24MOD-F8 OK"];
		}
		else
		{
			[statusField setStringValue:@"JW24MOD-F8 gefunden"];
		}
	}
	else
	{
		[statusField setStringValue:@"Kein JoyWarrior gefunden"];
	}

}

- (BOOL) currentDevicePassedTest
{
	if (currentDeviceType == kDeviceTypeJoyWarriorA8)
	{
		int	minCookie = 3;
		int maxCookie = 13;
		int	i;
		
		for (i = minCookie; i <= maxCookie; i++)
		{
			if (kButtonStateTested != [(ButtonView*) [self buttonViewWithTag:i] buttonState])
				return NO;
		}
		return YES;
	}
	else if (currentDeviceType == kDeviceTypeJoyWarriorA16)
	{
		// axis buttons
		int	minCookie = 11;
		int maxCookie = 13;
		int	i;
		
		for (i = minCookie; i <= maxCookie; i++)
		{
			if (kButtonStateTested != [(ButtonView*) [self buttonViewWithTag:i] buttonState])
				return NO;
		}
		minCookie = 103;
		maxCookie = 106;
		
		// low row buttons
		for (i = minCookie; i <= maxCookie; i++)
		{
			if (kButtonStateTested != [(ButtonView*) [self buttonViewWithTag:i] buttonState])
				return NO;
		}
		
		minCookie = 110;
		maxCookie = 118;
		
		// up column buttons
		for (i = minCookie; i <= maxCookie; i += 4)
		{
			if (kButtonStateTested != [(ButtonView*) [self buttonViewWithTag:i] buttonState])
				return NO;
		}
		
		return YES;
	}
	return NO;
}

- (int) armUSBNotifications
{
	SInt32                  usbVendor;
    SInt32                  usbProduct;
    kern_return_t           result;
    mach_port_t             masterPort;
    CFMutableDictionaryRef  matchingDict;
    CFRunLoopSourceRef      runLoopSource;

	gController = self;
	
	//Create a master port for communication with the I/O Kit
    result = IOMasterPort(MACH_PORT_NULL, &masterPort);
    if (result || !masterPort)
    {
        return -1;
    }
	
    //To set up asynchronous notifications, create a notification port and
    //add its run loop event source to the programs run loop
    gNotifyPort = IONotificationPortCreate(masterPort);
    runLoopSource = IONotificationPortGetRunLoopSource(gNotifyPort);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource,
                       kCFRunLoopDefaultMode);
    
	//Set up matching dictionary for class IOUSBDevice and its subclasses
    matchingDict = IOServiceMatching(kIOUSBDeviceClassName);
    if (!matchingDict)
    {
        //printf("Couldn't create a USB matching dictionary\n");
        mach_port_deallocate(mach_task_self(), masterPort);
        return -1;
    }
	
    //Add the vendor and product IDs to the matching dictionary
    //This is the second key of the first table in the USB Common Class
    //Specification
		
	usbVendor = 1984;
    usbProduct = kJoyWarrior24A8ID;

    CFDictionarySetValue(matchingDict, CFSTR(kUSBVendorName),
                         CFNumberCreate(kCFAllocatorDefault,
                                        kCFNumberSInt32Type, &usbVendor));
    CFDictionarySetValue(matchingDict, CFSTR(kUSBProductName),
						 CFNumberCreate(kCFAllocatorDefault,
										kCFNumberSInt32Type, &usbProduct));
	
	//Now set up two notifications: one to be called when a raw device
    //is first matched by the I/O Kit and another to be called when the
    //device is terminated
    //Notification of first match
	CFRetain(matchingDict);
    result = IOServiceAddMatchingNotification(gNotifyPort,
                                              kIOFirstMatchNotification, matchingDict,
                                              JoyWarriorAdded, NULL, &gJoyWarriorAddedIter);
    //Iterate over set of matching devices to access already-present devices
    //and to arm the notification
    JoyWarriorAdded(NULL, gJoyWarriorAddedIter);
	
    //Notification of termination
    CFRetain(matchingDict);
    result = IOServiceAddMatchingNotification(gNotifyPort,
                                              kIOTerminatedNotification, matchingDict,
                                              JoyWarriorRemoved, NULL, &gJoyWarriorRemovedIter);
	JoyWarriorRemoved(NULL, gJoyWarriorRemovedIter);
	
	usbVendor = 1984;
    usbProduct = kJoyWarrior24A16ID;
	
    CFDictionarySetValue(matchingDict, CFSTR(kUSBVendorName),
                         CFNumberCreate(kCFAllocatorDefault,
                                        kCFNumberSInt32Type, &usbVendor));
    CFDictionarySetValue(matchingDict, CFSTR(kUSBProductName),
						 CFNumberCreate(kCFAllocatorDefault,
										kCFNumberSInt32Type, &usbProduct));
	
	//Now set up two notifications: one to be called when a raw device
    //is first matched by the I/O Kit and another to be called when the
    //device is terminated
    //Notification of first match
	CFRetain(matchingDict);
    result = IOServiceAddMatchingNotification(gNotifyPort,
                                              kIOFirstMatchNotification, matchingDict,
                                              JoyWarriorAdded, NULL, &gJoyWarriorAddedIter);
    //Iterate over set of matching devices to access already-present devices
    //and to arm the notification
    JoyWarriorAdded(NULL, gJoyWarriorAddedIter);
	
	usbVendor = 1984;
    usbProduct = kJoyWarrior24F8ID;
	
    CFDictionarySetValue(matchingDict, CFSTR(kUSBVendorName),
                         CFNumberCreate(kCFAllocatorDefault,
                                        kCFNumberSInt32Type, &usbVendor));
    CFDictionarySetValue(matchingDict, CFSTR(kUSBProductName),
						 CFNumberCreate(kCFAllocatorDefault,
										kCFNumberSInt32Type, &usbProduct));
	
	//Now set up two notifications: one to be called when a raw device
    //is first matched by the I/O Kit and another to be called when the
    //device is terminated
    //Notification of first match
	CFRetain(matchingDict);
    result = IOServiceAddMatchingNotification(gNotifyPort,
                                              kIOFirstMatchNotification, matchingDict,
                                              JoyWarriorAdded, NULL, &gJoyWarriorAddedIter);
    //Iterate over set of matching devices to access already-present devices
    //and to arm the notification
    JoyWarriorAdded(NULL, gJoyWarriorAddedIter);
	
	
    //Notification of termination
    CFRetain(matchingDict);
    result = IOServiceAddMatchingNotification(gNotifyPort,
                                              kIOTerminatedNotification, matchingDict,
                                              JoyWarriorRemoved, NULL, &gJoyWarriorRemovedIter);
	JoyWarriorRemoved(NULL, gJoyWarriorRemovedIter);
	
	
	
    CFRelease(matchingDict);
    //Finished with master port
    mach_port_deallocate(mach_task_self(), masterPort);	
	
	return 0;
}

- (void) incrementDeviceCounter
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	int				count = [defaults integerForKey:@"deviceCount"];
	
	count++;
	[defaults setInteger:count forKey:@"deviceCount"];
	[defaults synchronize];
}

- (IBAction) resetDeviceCounterAction:(id) sender
{
	[self resetDeviceCounter];
}

- (void) resetDeviceCounter
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setInteger:0 forKey:@"deviceCount"];
	[defaults synchronize];
}

@end

void JoyWarriorAdded(void *refCon, io_iterator_t iterator)
{	
	
	io_service_t            usbDevice;

	while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
    }
	gDeviceListDirty = YES;
}

void JoyWarriorRemoved(void *refCon, io_iterator_t iterator)
{
	io_service_t            usbDevice;

	while (usbDevice = IOIteratorNext(iterator))
	{
		IOObjectRelease(usbDevice);
    }
	gDeviceListDirty = YES;
}

