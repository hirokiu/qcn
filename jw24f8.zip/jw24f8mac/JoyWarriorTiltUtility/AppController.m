#import "AppController.h"
#import "AppController+Devices.h"
#import "DiscoverHIDInterface.h"
#import <IOKit/hid/IOHIDLib.h>


void JoyWarriorAddedOrRemoved(void *refCon, io_iterator_t iterator)
{
    io_service_t            usbDevice;
    
    while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
    }
	[[NSApp delegate] updateDeviceState];
}

@implementation AppController

- (void) dealloc
{
	[self setXAxis: nil];
    [self setXAxisDegrees: nil];
    [self setXAxisPercent: nil];
    [self setYAxis: nil];
    [self setYAxisDegrees: nil];
    [self setYAxisPercent: nil];
    [self setZAxis: nil];
	
    [super dealloc];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{	
	AddUSBDeviceAddedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	
	AddUSBDeviceAddedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	
	[self updateDeviceState];

}



- (BOOL) deviceConnected
{
	
    return deviceConnected;
}

- (void) setDeviceConnected: (BOOL) flag
{
	deviceConnected = flag;
}


- (void) updateDeviceState
{
	CFMutableArrayRef interfaces;
	
	interfaces = [self discoverInterfaces];
	[self setDeviceConnected:(nil != interfaces) && (CFArrayGetCount (interfaces) >= 2)];
	if (deviceConnected)
	{
		CFMutableArrayRef deviceProperties;
		CFNumberRef					interfaceRef;
			
		interfaceRef =	CFArrayGetValueAtIndex(interfaces,1);
		CFNumberGetValue(interfaceRef,kCFNumberLongType,&interface);
		
		deviceProperties = [self discoverDeviceProperties];
		
		if ( CFArrayGetCount (deviceProperties))
		{
			CFDictionaryRef	  properties = CFArrayGetValueAtIndex(deviceProperties, 0);
			[deviceTypeField setStringValue:[(NSDictionary*) properties valueForKey:@"Product"]]; 
			[deviceSerialField setStringValue:[(NSDictionary*) properties valueForKey:@"SerialNumber"]];
		}
		
		CFRelease (deviceProperties);
		
		readTimer = [NSTimer scheduledTimerWithTimeInterval:0.2
													 target:self
												   selector:@selector (readAxisValuesTimed:)
												   userInfo:nil
													repeats:YES];
	}
	else
	{
		interface = 0;
		
		[readTimer invalidate];
		readTimer = nil;
		
		[deviceSerialField setStringValue:@""];
		[deviceTypeField setStringValue:@""];
		
	}
	if (interfaces)
		CFRelease (interfaces);
}

- (void) readAxisValuesTimed:(NSTimer*) inTimer
{
	if (interface)
	{
		UInt8						rawData[6];
		int							i;
		SInt16						x, y, z;
		double						xDegrees = 0, yDegrees = 0, xPercentage = 0, yPercentage = 0;
		for (i = 0; i < 6; i++)
		{
			JWReadByteFromAddress (interface, 0x02 + i, &rawData[i]);
		}
		x = JWMergeAxisBytes(rawData[0], rawData[1]);
		y = JWMergeAxisBytes(rawData[2], rawData[3]);
		z = JWMergeAxisBytes(rawData[4], rawData[5]);
		
		xDegrees = [self calculateAxisDegrees:x];
		yDegrees = [self calculateAxisDegrees:y];
		
		xPercentage = [self caclculateAxisPercent:x];
		yPercentage = [self caclculateAxisPercent:y];

		[self setXAxis:[NSString stringWithFormat:@"%d", x]];
		[self setXAxisDegrees:[NSString stringWithFormat:@"%.2f°", xDegrees]];
		[self setXAxisPercent:[NSString stringWithFormat:@"%.2f%", xPercentage]];
		
		[self setYAxis:[NSString stringWithFormat:@"%d", y]];
		[self setYAxisDegrees:[NSString stringWithFormat:@"%.2f°", yDegrees]];
		[self setYAxisPercent:[NSString stringWithFormat:@"%.2f%", yPercentage]];

		[self setZAxis:[NSString stringWithFormat:@"%d", z]];
	}
}

- (double) caclculateAxisPercent:(SInt16) inAxisValue 
{
	UInt16	limitValue = 256;
	double	sin;
	double	value = inAxisValue;
	
	sin = value / limitValue;

	return 100.0 * tan (asin (sin));
}

- (double) calculateAxisDegrees:(SInt16) inAxisValue
{
	UInt16	limitValue = 256;
	double	sin;
	double	value = inAxisValue;
	bool	limit = true;
	double  degrees;
	
	sin = value / limitValue;
	
	if (value > limitValue)
		limit = false;
	
	//*outPercentage = 100.0 * tan (asin (sin));
	//*outDegrees = degrees = asin (sin) * 180/M_PI;
	
	degrees = asin (sin) * 180/M_PI;
	
	return degrees;
}

- (NSString *) xAxis
{
    return xAxis; 
}

- (void) setXAxis: (NSString *) inXAxis
{
    if (xAxis != inXAxis) {
        [xAxis autorelease];
        xAxis = [inXAxis retain];
    }
}


- (NSString *) xAxisDegrees
{
    return xAxisDegrees; 
}

- (void) setXAxisDegrees: (NSString *) inXAxisDegrees
{
    if (xAxisDegrees != inXAxisDegrees) {
        [xAxisDegrees autorelease];
        xAxisDegrees = [inXAxisDegrees retain];
    }
}


- (NSString *) xAxisPercent
{
    return xAxisPercent; 
}

- (void) setXAxisPercent: (NSString *) inXAxisPercent
{
    if (xAxisPercent != inXAxisPercent) {
        [xAxisPercent autorelease];
        xAxisPercent = [inXAxisPercent retain];
    }
}


- (NSString *) yAxis
{
    return yAxis; 
}

- (void) setYAxis: (NSString *) inYAxis
{
    if (yAxis != inYAxis) {
        [yAxis autorelease];
        yAxis = [inYAxis retain];
    }
}


- (NSString *) yAxisDegrees
{
    return yAxisDegrees; 
}

- (void) setYAxisDegrees: (NSString *) inYAxisDegrees
{
    if (yAxisDegrees != inYAxisDegrees) {
        [yAxisDegrees autorelease];
        yAxisDegrees = [inYAxisDegrees retain];
    }
}


- (NSString *) yAxisPercent
{
    return yAxisPercent; 
}

- (void) setYAxisPercent: (NSString *) inYAxisPercent
{
    if (yAxisPercent != inYAxisPercent) {
        [yAxisPercent autorelease];
        yAxisPercent = [inYAxisPercent retain];
    }
}


- (NSString *) zAxis
{
    return zAxis; 
}

- (void) setZAxis: (NSString *) inZAxis
{
    if (zAxis != inZAxis) {
        [zAxis autorelease];
        zAxis = [inZAxis retain];
    }
}


@end
