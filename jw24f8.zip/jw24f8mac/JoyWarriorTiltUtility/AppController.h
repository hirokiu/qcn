#import <Cocoa/Cocoa.h>

@class IOHIDDeviceInterface122;

@interface AppController : NSObject /* Specify a superclass (eg: NSObject or NSView) */ {

	BOOL					deviceConnected;
	
	IBOutlet NSTextField	*deviceTypeField;
	IBOutlet NSTextField	*deviceSerialField;
	
	IOHIDDeviceInterface122**	interface;

	NSTimer	*readTimer;
	
	NSString	*xAxis;
	NSString	*xAxisDegrees;
	NSString	*xAxisPercent;
	
	NSString	*yAxis;
	NSString	*yAxisDegrees;
	NSString	*yAxisPercent;
	
	NSString	*zAxis;
}

- (void) updateDeviceState;

- (BOOL) deviceConnected;
- (void) setDeviceConnected: (BOOL) flag;

- (double) calculateAxisDegrees:(SInt16) inAxisValue;
- (double) caclculateAxisPercent:(SInt16) inAxisValue;

- (NSString *) xAxis;
- (void) setXAxis: (NSString *) inXAxis;

- (NSString *) xAxisDegrees;
- (void) setXAxisDegrees: (NSString *) inXAxisDegrees;

- (NSString *) xAxisPercent;
- (void) setXAxisPercent: (NSString *) inXAxisPercent;

- (NSString *) yAxis;
- (void) setYAxis: (NSString *) inYAxis;

- (NSString *) yAxisDegrees;
- (void) setYAxisDegrees: (NSString *) inYAxisDegrees;

- (NSString *) yAxisPercent;
- (void) setYAxisPercent: (NSString *) inYAxisPercent;



- (NSString *) zAxis;
- (void) setZAxis: (NSString *) inZAxis;



@end
