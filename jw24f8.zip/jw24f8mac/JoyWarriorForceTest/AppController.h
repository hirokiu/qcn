/* AppController */

#import <Cocoa/Cocoa.h>

@class Settings; 

@interface AppController : NSObject
{
	NSString	*ioWarriorStateString;
	BOOL		ioWarriorConnected;
	
	BOOL		joyWarriorConnected;
	
	NSString	*joyWarriorSerialNumber;
	
	NSArray		*hidButtonTestResults;
	
	NSString	*alVersion;
	NSString	*mlVersion;
	
	NSString	*versionTestState;
	NSString	*hidTestState;
	NSString	*selfTestState;
	
	NSString	*writeSettingsState;
	
	NSString	*lastFileName;
	Settings	*currentSettings;
	
	IBOutlet	NSWindow	*mainWindow;
	IBOutlet	NSDrawer	*logDrawer;
	IBOutlet	NSTextView	*logTextView;
}

- (IBAction) chooseSettingsFile:(id) sender;
- (IBAction) clearSettingsFile:(id) sender;
- (IBAction) runTestAgain:(id) sender;

- (NSString *) ioWarriorStateString;
- (void) setIoWarriorStateString: (NSString *) inIoWarriorStateString;

- (void) updateIOWarriorState;

- (BOOL) ioWarriorConnected;
- (void) setIoWarriorConnected: (BOOL) flag;


- (BOOL) joyWarriorConnected;
- (void) setJoyWarriorConnected: (BOOL) flag;

- (void) updateJoyWarriorStateWithIterator:(io_iterator_t) iterator;

- (NSString *) joyWarriorSerialNumber;
- (void) setJoyWarriorSerialNumber: (NSString *) inJoyWarriorSerialNumber;

- (NSString *) alVersion;
- (void) setAlVersion: (NSString *) inAlVersion;

- (NSString *) mlVersion;
- (void) setMlVersion: (NSString *) inMlVersion;

- (void) performTests;
- (int) performSensorVersionTest;
- (int) performHIDTest;

- (int) performSelfTest;

- (NSString *) versionTestState;
- (void) setVersionTestState: (NSString *) inVersionTestState;

- (NSString *) hidTestState;
- (void) setHidTestState: (NSString *) inHidTestState;

- (NSString *) selfTestState;
- (void) setSelfTestState: (NSString *) inSelfTestState;

- (NSArray *) hidButtonTestResults;
- (void) setHidButtonTestResults: (NSArray *) inHidButtonTestResults;

- (NSString *) lastFileName;
- (void) setLastFileName: (NSString *) inLastFileName;

- (Settings *) currentSettings;
- (void) setCurrentSettings: (Settings *) inCurrentSettings;

- (void) loadSettingsFromFile:(NSString*) inPath;
- (int) writeCurrentSettingsToEEPROM;

- (NSString *) writeSettingsState;
- (void) setWriteSettingsState: (NSString *) inWriteSettingsState;

- (void) logErrorString:(NSString*) inString;
- (void) logString:(NSString*) inString;
- (void) addLogString:(NSString*) inString withColor:(NSColor*) inColor;

- (void) lightIOWarriorLEDWithColor:(int) inLEDIdentifier;
@end
