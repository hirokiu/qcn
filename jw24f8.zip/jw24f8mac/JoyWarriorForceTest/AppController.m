#import "AppController.h"
#import "IOWarriorLib.h"
#import "DiscoverHIDInterface.h"
#import "HID_Utilities.h"
#import "Settings.h"

#define kLEDNone	-1
#define kLEDRed		0
#define kLEDYellow	1
#define kLEDGreen	2

void IOWarriorAddedOrRemoved (void *inRefcon)
{
	[[NSApp delegate] updateIOWarriorState];
}

void JoyWarriorAddedOrRemoved (void *refcon,io_iterator_t iterator )
{
	io_service_t            usbDevice;
    
    while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
	}
	[[NSApp delegate] updateJoyWarriorStateWithIterator:iterator];
}


@implementation AppController

- (void) awakeFromNib
{
	[logDrawer setParentWindow:mainWindow];
	[logDrawer setPreferredEdge:NSMaxXEdge];
	[logDrawer open];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	IOWarriorInit();
	IOWarriorSetDeviceCallback(IOWarriorAddedOrRemoved, 0);
	[self updateIOWarriorState];
	
	[self setLastFileName:nil];

	// JoyWarrior 24F8
	AddUSBDeviceAddedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	//MouseWarrior 24F6
	AddUSBDeviceAddedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	
	[self updateJoyWarriorStateWithIterator:0];
	
}

- (CFMutableArrayRef) joyWarriorInterfaces
{
	CFMutableArrayRef	interfaces, interfaces2;
	
	// JoyWarrior 24F8
	interfaces = DiscoverHIDInterfaces (0x07c0, 0x1113);
	// MouseWarrior24F6
	interfaces2 = DiscoverHIDInterfaces (0x07c0, 0x1114);
	
	CFArrayAppendArray(interfaces, 
					   interfaces2,
					   CFRangeMake(0,CFArrayGetCount (interfaces2)));
	
	return interfaces;
}

- (CFMutableArrayRef) joyWarriorInterfaceProperties
{
	CFMutableArrayRef	interfaceProperties, interfaceProperties2;
	
	// JoyWarrior 24F8
	interfaceProperties = DiscoverHIDDeviceProperties (0x07c0, 0x1113);
	// MouseWarrior24F6
	interfaceProperties2 = DiscoverHIDDeviceProperties (0x07c0, 0x1114);
	
	CFArrayAppendArray(interfaceProperties, 
					   interfaceProperties2,
					   CFRangeMake(0,CFArrayGetCount (interfaceProperties2)));
	
	return interfaceProperties;
}

- (void) updateJoyWarriorStateWithIterator:(io_iterator_t) iterator
{
	CFMutableArrayRef	interfaceProperties;
	CFDictionaryRef		deviceProperties;
	
	[self lightIOWarriorLEDWithColor:kLEDNone];
	
	interfaceProperties = [self joyWarriorInterfaceProperties];

	[self setJoyWarriorConnected: (CFArrayGetCount(interfaceProperties) >= 2)];
	if (joyWarriorConnected)
	{
		deviceProperties = CFArrayGetValueAtIndex(interfaceProperties,1);
		[self setJoyWarriorSerialNumber:(NSString*) CFDictionaryGetValue(deviceProperties,@"SerialNumber")];
		[self logString:[NSString stringWithFormat:@"Found %@ %@", (NSString*) CFDictionaryGetValue(deviceProperties,@"Product"), [self joyWarriorSerialNumber]]];
	}
	else
	{
		[self setJoyWarriorSerialNumber:@"-"];
		[self setVersionTestState:@""];
		[self setHidTestState:@""];
		[self setSelfTestState:@""];
		[self setHidButtonTestResults:[NSArray array]];
	}
	CFRelease (interfaceProperties);
	
	if (joyWarriorConnected && ioWarriorConnected)
	{
		[self performTests];
	}
}

- (void) updateIOWarriorState
{
	IOWarriorHIDDeviceInterface	**interface = IOWarriorFirstInterfaceOfType(kIOWarrior24Interface0);
	
	[self setIoWarriorConnected:(interface != nil)];
	if (ioWarriorConnected)
	{
		[self setIoWarriorStateString:@"IOWarrior24 found."];
	}
	else
	{
		[self setIoWarriorStateString:@"IOWarrior24 not found."];
	}
}

- (void) dealloc
{
    [self setIoWarriorStateString: nil];
	[self setJoyWarriorSerialNumber: nil];
    [self setAlVersion: nil];
    [self setMlVersion: nil];
	[self setVersionTestState: nil];
    [self setHidTestState: nil];
    [self setSelfTestState: nil];
	[self setHidButtonTestResults: nil];
	[self setLastFileName: nil];
	[self setWriteSettingsState: nil];

    [super dealloc];
}


- (NSString *) ioWarriorStateString
{
    return ioWarriorStateString; 
}

- (void) setIoWarriorStateString: (NSString *) inIoWarriorStateString
{
    if (ioWarriorStateString != inIoWarriorStateString) {
        [ioWarriorStateString autorelease];
        ioWarriorStateString = [inIoWarriorStateString retain];
    }
}

- (BOOL) ioWarriorConnected
{
    return ioWarriorConnected;
}

- (void) setIoWarriorConnected: (BOOL) flag
{
	ioWarriorConnected = flag;
}


- (BOOL) joyWarriorConnected
{
    return joyWarriorConnected;
}

- (void) setJoyWarriorConnected: (BOOL) flag
{
	joyWarriorConnected = flag;
}

- (NSString *) joyWarriorSerialNumber
{
    return joyWarriorSerialNumber; 
}

- (void) setJoyWarriorSerialNumber: (NSString *) inJoyWarriorSerialNumber
{
    if (joyWarriorSerialNumber != inJoyWarriorSerialNumber) {
        [joyWarriorSerialNumber autorelease];
        joyWarriorSerialNumber = [inJoyWarriorSerialNumber retain];
    }
}

- (void) performTests
{
	BOOL	sensorTest = NO;
	BOOL	hidTest = NO;
	BOOL	selfTest = NO;
	
	[self lightIOWarriorLEDWithColor:kLEDYellow];
	
	if ([self performSensorVersionTest])
	{
		sensorTest = NO;
		[self setVersionTestState:@"Sensor Version Test failed"];
		[self logErrorString:@"Sensor Version Test failed"];
	}
	else
	{
		sensorTest = YES;
		[self setVersionTestState:@"Sensor Version Test succeeded"];
	}
	if ([self performHIDTest])
	{
		hidTest = NO;
		[self setHidTestState:@"HID Buttons Test failed"];
		[self logErrorString:@"HID Buttons Test failed"];
	}
	else
	{
		hidTest = YES;
		[self setHidTestState:@"HID Buttons Test succeeded"];
	}
	if ([self performSelfTest])
	{
		selfTest = NO;
		[self setSelfTestState:@"Sensor Self-Test failed"];
		[self logErrorString:@"Sensor Self-Test failed"];
	}
	else
	{
		selfTest = YES;
		[self setSelfTestState:@"Sensor Self-Test succeeded"];
	}
	if (selfTest && hidTest && sensorTest)
	{
		[self logString:@"All Tests passed"];
		if ([self currentSettings])
		{
			[self writeCurrentSettingsToEEPROM];
			[self setWriteSettingsState:@"Settings written"];
			[self logString:[NSString stringWithFormat:@"Wrote settings %@ to EEPROM", [self lastFileName]]];
		}
		[self lightIOWarriorLEDWithColor:kLEDGreen];
		NSBeep ();
	}
	else
	{
		int i;
		[self setWriteSettingsState:@"Settings not written"];
		for (i = 0; i < 3 ; i++)
		{
			NSBeep ();
			[NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.3]];
		}
		[self lightIOWarriorLEDWithColor:kLEDRed];
	}
}

- (int) performSensorVersionTest
{
	CFMutableArrayRef	interfaces;
	int					err;
	
	[self setAlVersion:@""];
	[self setMlVersion:@""];
	
	interfaces = [self joyWarriorInterfaces];
	if (CFArrayGetCount (interfaces) >= 2)
	{
		CFNumberRef					interfaceRef;
		IOHIDDeviceInterface122		**hidInterface;
		UInt8						temp;
		
		interfaceRef = CFArrayGetValueAtIndex(interfaces,1);
		CFNumberGetValue(interfaceRef,kCFNumberLongType,&hidInterface);
		
		// read al_version and ml_version
		err = JWReadByteFromAddress (hidInterface, 0x01, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read chip version", err]];
			return err;
		}
		[self setAlVersion:[NSString stringWithFormat:@"%d", temp >> 4]]; 
		[self setMlVersion:[NSString stringWithFormat:@"%d", (temp & 0x0F)]];
		if ([[self alVersion] isEqualToString:@"0"] ||
			[[self mlVersion] isEqualToString:@"0"])
		{
			[self logErrorString:[NSString stringWithFormat:@"Chip version is 0 - Communication error ?", err]];
			return -1;
		}
	}
	ReleaseInterfaces(interfaces);
	
	return 0;
}

- (int) performHIDTest
{
	pRecDevice		testDevice = NULL;
	pRecDevice		theDevice = NULL;
	NSMutableArray	*testResults = [NSMutableArray array];
	
	[self setHidButtonTestResults:[NSArray array]];
	
	HIDBuildDeviceList (kHIDPage_GenericDesktop, kHIDUsage_GD_Joystick);
	
	if (theDevice = HIDGetFirstDevice())
	{		
		do
		{
			if ((theDevice->vendorID == 1984) && (theDevice->productID == 0x1113))
			{
				testDevice = theDevice;
				break;
			}
		}
		while (nil != (theDevice = HIDGetNextDevice (theDevice)));
	}
	if (NULL == theDevice)
	{
		HIDBuildDeviceList (kHIDPage_GenericDesktop, kHIDUsage_GD_Mouse);
		
		if (theDevice = HIDGetFirstDevice())
		{		
			do
			{
				if ((theDevice->vendorID == 1984) && (theDevice->productID == 0x1114))
				{
					testDevice = theDevice;
					break;
				}
			}
			while (nil != (theDevice = HIDGetNextDevice (theDevice)));
		}
	}
	if (NULL == theDevice)
	{
		[self logErrorString:@"Couldn't find HID device for testing"];
		return -1;
	}
	
	pRecElement theElement;
	BOOL		gotError = NO;
	
	theElement = HIDGetFirstDeviceElement(theDevice, kHIDElementTypeInput);
	while (theElement)
	{
		if (theElement->type == kIOHIDElementTypeInput_Button)
		{
			long							value;
			long							cookie = (long) theElement->cookie;
			char							buffer[2] = {0xFF, 0xFD};
			IOWarriorHIDDeviceInterface**	ioWarriorInterface = IOWarriorFirstInterfaceOfType(kIOWarrior24Interface0);
			BOOL							errorForThisButton = NO;

			IOWarriorWriteToInterface (ioWarriorInterface, 2, buffer);
			usleep (50000);
			value = HIDGetElementValue(theDevice,theElement);
			if (value != 0)
			{
				[self logErrorString:[NSString stringWithFormat:@"Button %d: Test failed.", cookie]];
				gotError = errorForThisButton = YES;
			}
			// turn off buffer bit for pin that's connected for this button
			buffer[0] = buffer[0] ^ (1 << (cookie - 3));
			
			IOWarriorWriteToInterface (ioWarriorInterface, 2, buffer);
			usleep (50000);
			value = HIDGetElementValue(theDevice,theElement);
			if (value != 1)
			{
				[self logErrorString:[NSString stringWithFormat:@"Button %d: Test failed.", cookie]];
				gotError = errorForThisButton = YES;
			}
			
			// test that all other buttons are actually turned off to catch short cuts
			pRecElement otherElement;
			
			otherElement = HIDGetFirstDeviceElement(theDevice, kHIDElementTypeInput);
			while (otherElement)
			{
				if ((otherElement->type == kIOHIDElementTypeInput_Button) && ((long) otherElement->cookie != cookie))
				{
					if (HIDGetElementValue(theDevice,otherElement) != 0)
					{
						[self logErrorString:[NSString stringWithFormat:@"Buttons %d and %d: Test failed.", cookie, (long) otherElement->cookie]];
						gotError = errorForThisButton = YES;
					}
				}
				otherElement = HIDGetNextDeviceElement(otherElement,kHIDElementTypeInput);
			}
			
			[testResults addObject:[NSDictionary dictionaryWithObjectsAndKeys:
				[NSString stringWithFormat:@"Button %d", cookie - 3], @"button", 
				(errorForThisButton ? @"NOT OK" : @"OK"), @"state", 
				nil]];
		}
		theElement = HIDGetNextDeviceElement(theElement,kHIDElementTypeInput);
	}
	[self setHidButtonTestResults:testResults];
	
	return (gotError ? -1 : 0);
}

- (int) performSelfTest
{
	CFMutableArrayRef	interfaces;
	int					err;
	UInt8				temp = 0;

	interfaces = [self joyWarriorInterfaces];
	if (CFArrayGetCount (interfaces) >= 2)
	{
		CFNumberRef					interfaceRef;
		IOHIDDeviceInterface122		**hidInterface;
		
		interfaceRef = CFArrayGetValueAtIndex(interfaces,1);
		CFNumberGetValue(interfaceRef,kCFNumberLongType,&hidInterface);
		
		err = JWWriteByteToAddress( hidInterface, 0x0A, (1 << 2));
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to set selftest_0 bit", err]];
			return err;
		}
		// wait until selftest_0  is set to zero to indicate that self test is over
		do
		{
			usleep (50000);
			err = JWReadByteFromAddress (hidInterface, 0x0A, &temp);
		} while (temp & (1 << 2));
		usleep (50000);
		err = JWReadByteFromAddress (hidInterface, 0x09, &temp);
	}
	ReleaseInterfaces(interfaces);	
	
	return (temp & (1 << 7) ? 0 : -1); 
}

- (NSString *) alVersion
{
    return alVersion; 
}

- (void) setAlVersion: (NSString *) inAlVersion
{
    if (alVersion != inAlVersion) {
        [alVersion autorelease];
        alVersion = [inAlVersion retain];
    }
}


- (NSString *) mlVersion
{
    return mlVersion; 
}

- (void) setMlVersion: (NSString *) inMlVersion
{
    if (mlVersion != inMlVersion) {
        [mlVersion autorelease];
        mlVersion = [inMlVersion retain];
    }
}

- (void) logErrorString:(NSString*) inString
{
	[self addLogString:inString withColor:[NSColor redColor]];
}

- (void) logString:(NSString*) inString
{
	[self addLogString:inString withColor:[NSColor blackColor]];
}

- (NSString *) versionTestState
{
    return versionTestState; 
}

- (void) setVersionTestState: (NSString *) inVersionTestState
{
    if (versionTestState != inVersionTestState) {
        [versionTestState autorelease];
        versionTestState = [inVersionTestState retain];
    }
}


- (NSString *) hidTestState
{
    return hidTestState; 
}

- (void) setHidTestState: (NSString *) inHidTestState
{
    if (hidTestState != inHidTestState) {
        [hidTestState autorelease];
        hidTestState = [inHidTestState retain];
    }
}


- (NSString *) selfTestState
{
    return selfTestState; 
}

- (void) setSelfTestState: (NSString *) inSelfTestState
{
    if (selfTestState != inSelfTestState) {
        [selfTestState autorelease];
        selfTestState = [inSelfTestState retain];
    }
}

- (NSArray *) hidButtonTestResults
{
    return hidButtonTestResults; 
}

- (void) setHidButtonTestResults: (NSArray *) inHidButtonTestResults
{
    if (hidButtonTestResults != inHidButtonTestResults) {
        [hidButtonTestResults autorelease];
        hidButtonTestResults = [inHidButtonTestResults retain];
    }
}

- (NSString *) lastFileName
{
    return lastFileName; 
}

- (void) setLastFileName: (NSString *) inLastFileName
{
    if (lastFileName != inLastFileName) {
        [lastFileName autorelease];
        lastFileName = [inLastFileName retain];
    }
}


- (IBAction) chooseSettingsFile:(id) sender
{
	NSOpenPanel *openPanel= [NSOpenPanel openPanel];
	
	[openPanel setCanChooseDirectories:NO];
	[openPanel setCanChooseFiles:YES];
	if ([openPanel runModalForDirectory:nil
								   file:nil
								  types:[NSArray arrayWithObject:@"jwSettings"]])
	{
		[self loadSettingsFromFile:[openPanel filename]];
	}	
}

- (void) loadSettingsFromFile:(NSString*) inPath
{
	[self setCurrentSettings:[NSKeyedUnarchiver unarchiveObjectWithFile:inPath]];
	[self setLastFileName:[[NSFileManager defaultManager] displayNameAtPath:inPath]];
}

- (IBAction) clearSettingsFile:(id) sender
{
	[self setCurrentSettings:nil];
	[self setLastFileName:nil];
}

- (Settings *) currentSettings
{
    return currentSettings; 
}

- (void) setCurrentSettings: (Settings *) inCurrentSettings
{
    if (currentSettings != inCurrentSettings) {
        [currentSettings autorelease];
        currentSettings = [inCurrentSettings retain];
		[currentSettings setUseEEPROM:YES]; // we only write to EEPROM in this test tool
    }
}

- (int) writeCurrentSettingsToEEPROM
{
	UInt8						emptyData[11];
	CFNumberRef					hidInterfaceRef;
	IOHIDDeviceInterface122		**hidInterface;
	int							address;
	NSData						*reportData;
	UInt8*						reportDataBytes;
	CFMutableArrayRef			interfaces;
	int							addressOffset = 0;
	
	interfaces =[self joyWarriorInterfaces];
	hidInterfaceRef = CFArrayGetValueAtIndex(interfaces,1);
	CFNumberGetValue(hidInterfaceRef,kCFNumberLongType,&hidInterface);
	
	if ([currentSettings useEEPROM])
	{
		// force eeprom content to be written to image
		JWWriteByteToAddress (hidInterface, 0x0A, 0x20);
	}
	
	bzero (emptyData,sizeof(emptyData));
	// read byte at 0x14 to get value of reserved field
	JWReadByteFromAddress(hidInterface,0x14,&emptyData[9]);
	
	reportData = [[self currentSettings] reportDataWithReadData:[NSData dataWithBytes:emptyData
																			   length:11]];
	
	reportDataBytes =  (UInt8*)[reportData bytes];
	
	if ([currentSettings useEEPROM])
	{
		// unlock eeprom
		JWWriteByteToAddress (hidInterface, 0x0A, 0x10);
	}
	
	if ([currentSettings useEEPROM])
		addressOffset = 0x20;
	
	for (address = 0x0B; address < 0x16; address++)
	{
		
		JWWriteByteToAddress (hidInterface, address + addressOffset, reportDataBytes[address - 0x0B]);
		if ([currentSettings useEEPROM])
			usleep(10000);
	}
	
	if ([currentSettings useEEPROM])
	{
		// force eeprom content to be written to image
		JWWriteByteToAddress (hidInterface, 0x0A, 0x20);
	}
	
	ReleaseInterfaces (interfaces);
	CFRelease (interfaces);
	
	return 0;
}

- (IBAction) runTestAgain:(id) sender
{
	[self performTests];
}

- (NSString *) writeSettingsState
{
    return writeSettingsState; 
}

- (void) setWriteSettingsState: (NSString *) inWriteSettingsState
{
    if (writeSettingsState != inWriteSettingsState) {
        [writeSettingsState autorelease];
        writeSettingsState = [inWriteSettingsState retain];
    }
}

- (void) addLogString:(NSString*) inString withColor:(NSColor*) inColor
{
	inString = [inString stringByAppendingString:@"\n"];
	
	NSMutableAttributedString	*attributedString = [[[NSMutableAttributedString alloc] initWithString:inString] autorelease];
	
	[attributedString addAttributes:[NSDictionary dictionaryWithObject:inColor forKey:NSForegroundColorAttributeName]
							  range:NSMakeRange (0, [attributedString length])];
	[attributedString addAttributes:[NSDictionary dictionaryWithObject:[NSFont systemFontOfSize:12.0] forKey:NSFontAttributeName]
							  range:NSMakeRange (0, [attributedString length])];
	
	[[logTextView textStorage] appendAttributedString:attributedString];
	
	
	[logTextView scrollRangeToVisible:NSMakeRange ([[logTextView textStorage] length] -1, 0)];
}

- (void) lightIOWarriorLEDWithColor:(int) inLEDIdentifier
{
	IOWarriorHIDDeviceInterface**	ioWarriorInterface = IOWarriorFirstInterfaceOfType(kIOWarrior24Interface0);
	char							buffer[2] = {0xFF, 0xFF};

	if (ioWarriorInterface)
	{
		if (inLEDIdentifier != kLEDNone)
		{
			buffer[1] = 0xFF ^ (1 << inLEDIdentifier);
		}
		IOWarriorWriteToInterface (ioWarriorInterface, 2, buffer);
	}
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

@end
