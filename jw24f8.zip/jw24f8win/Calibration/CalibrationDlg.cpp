// CalibrationDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "Calibration.h"
#include "CalibrationDlg.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define VID 0x07C0
#define MW 0x1114
#define JW 0x1113

// CCalibrationDlg-Dialogfeld




CCalibrationDlg::CCalibrationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCalibrationDlg::IDD, pParent)
	, cBool(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCalibrationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, mList);
	DDX_Control(pDX, IDC_STATUS, cStatusMsg);
	DDX_Control(pDX, IDC_STATIC_SERIAL, cSerial);
}

BEGIN_MESSAGE_MAP(CCalibrationDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_DEVICECHANGE, &CCalibrationDlg::OnDeviceChange)
	ON_BN_CLICKED(IDC_CALIBRATE, &CCalibrationDlg::OnBnClickedCalibrate)
	ON_WM_CLOSE()
	ON_WM_CTLCOLOR()
	ON_COMMAND(ID_FILE_EXIT, &CCalibrationDlg::OnFileExit)
	ON_COMMAND(ID_FUNCTIONS_MANUALGAIN, &CCalibrationDlg::OnFunctionsManualgain)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CCalibrationDlg-Meldungshandler

BOOL CCalibrationDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	/*Create CListCtl-cols*/
	mList.InsertColumn(0, _T("Axis"), LVCFMT_LEFT, 60);
	mList.InsertColumn(1, _T("Offset"), LVCFMT_LEFT, 100);
	mList.InsertColumn(3, _T("Output"), LVCFMT_LEFT, 50);
	mList.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);


	cBool = FALSE;
	cStatusMsg.SetWindowTextW(_T("No Device Found"));
	cSerial.SetWindowTextW(_T("- - -"));
	GetDlgItem(IDC_STATIC_X)->SetWindowTextW(_T("-1"));
	GetDlgItem(IDC_STATIC_Y)->SetWindowTextW(_T("-1"));
	GetDlgItem(IDC_STATIC_Z)->SetWindowTextW(_T("-1"));

	/*Enumerate HID-Devices*/
	ConnectToHid(0, 0x07C0);

	/*If compatible HID-Device found Read data*/
	if(dBool == TRUE)
	{
		ReadCalib();
		SetTimer(ID_LOOPTIME, 50, NULL);
	}

	return TRUE;
}

void CCalibrationDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CCalibrationDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CCalibrationDlg::ConnectToHid(ULONG productID, ULONG vendorID)
{
	HIDD_ATTRIBUTES	Attributes;
	SP_DEVICE_INTERFACE_DATA devInfoData;
	PSP_DEVICE_INTERFACE_DETAIL_DATA detailData;
	HDEVINFO hDevInfo;
	int	MemberIndex = 0;
	int	DeviceIndex = 0;
	LONG DevInfo;
	ULONG Length = 0;
	GUID HidGuid;
	ULONG Required;

    ZeroMemory(&devInfoData, sizeof(devInfoData));
    devInfoData.cbSize = sizeof(devInfoData);

	HidD_GetHidGuid(&HidGuid);	

	hDevInfo = SetupDiGetClassDevsW(&HidGuid, NULL, NULL, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);

	do{
		DevInfo = SetupDiEnumDeviceInterfaces (hDevInfo, NULL, &HidGuid, MemberIndex, &devInfoData);

		if (DevInfo != 0)
		{
			SetupDiGetDeviceInterfaceDetailW(hDevInfo, &devInfoData, NULL, 0, &Length, NULL);

			detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(Length);
			detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

			SetupDiGetDeviceInterfaceDetailW(hDevInfo, &devInfoData, detailData, Length, &Required, NULL);

			DeviceHandle = CreateFile (detailData->DevicePath, 0, FILE_SHARE_READ|FILE_SHARE_WRITE, (LPSECURITY_ATTRIBUTES)NULL, OPEN_EXISTING, 0, NULL);

			Attributes.Size = sizeof(Attributes);
			HidD_GetAttributes (DeviceHandle, &Attributes);

			if (Attributes.VendorID == vendorID) 
			{
				if((Attributes.ProductID == JW) || (Attributes.ProductID == MW))
				{
					cBool = TRUE;
					if(Attributes.ProductID == JW) cStatusMsg.SetWindowTextW(_T("JoyWarrior"));
					if(Attributes.ProductID == MW) cStatusMsg.SetWindowTextW(_T("MouseWarrior"));
				
					GetPreparsedData(DeviceHandle);

					DevHandle[DeviceIndex] = CreateFileW(detailData->DevicePath, 
														GENERIC_WRITE | GENERIC_READ, 
														FILE_SHARE_READ|FILE_SHARE_WRITE, 
														(LPSECURITY_ATTRIBUTES)NULL, 
														OPEN_EXISTING, 
														0, 
														NULL);

					dBool = TRUE;
					cSerial.SetWindowTextW(GetSerialNumber(DeviceHandle));

					DeviceIndex++;
				}
				else
					NULL;
			}
			else
				CloseHandle(DeviceHandle);

			free(detailData);
		}

		MemberIndex++;

	}while (DevInfo != NULL);

	SetupDiDestroyDeviceInfoList(hDevInfo);
}


/*
Get Serialnumber from device
*/
CString CCalibrationDlg::GetSerialNumber(HANDLE handle)
{
	WCHAR sn[32];
	CString	serial;
	
	memset(&sn, 0, 32);
	HidD_GetSerialNumberString(handle, &sn, 32); 

	serial.Format(_T("SN: %s"), &sn[0]);

	return serial;
}

void CCalibrationDlg::GetPreparsedData(HANDLE handle)
{
	PHIDP_PREPARSED_DATA	PreparsedData;

	HidD_GetPreparsedData(handle, &PreparsedData);
	HidP_GetCaps(PreparsedData, &Capabilities);
	HidD_FreePreparsedData(PreparsedData);
}

/*
Write data t o device
*/
BOOL CCalibrationDlg::WriteData(HANDLE handle, UCHAR cmd, UCHAR addr, UCHAR data)
{
	UCHAR newAddr;
	UCHAR WriteBuffer[12];
	UCHAR ReadBuffer[12];
	BOOL Result;
	DWORD BytesWritten;
	DWORD NumberOfBytesRead;

	newAddr = 0x00 | addr;
	memset(WriteBuffer, 0, 12);

	WriteBuffer[0] = 0x00; //ReportID
	WriteBuffer[1] = cmd; //Command
	WriteBuffer[2] = newAddr; //Register
	WriteBuffer[3] = data; //Data

	Result = WriteFile(handle, &WriteBuffer, Capabilities.OutputReportByteLength, &BytesWritten, NULL);

	if(Result != NULL)
	{
		memset(&ReadBuffer, 0, Capabilities.InputReportByteLength+1);
		ReadBuffer[0] = 0x00;

		ReadFile(handle, &ReadBuffer, Capabilities.InputReportByteLength, &NumberOfBytesRead, NULL);
	}
	return 0;
}

/*
Read data t o device
*/
UCHAR CCalibrationDlg::ReadData(HANDLE handle, UCHAR cmd, UCHAR addr)
{
	UCHAR			WriteBuffer[12];
	UCHAR			ReadBuffer[12];
	UCHAR			newAddr;
	DWORD			BytesWritten = 0;
	DWORD			NumberOfBytesRead = 0;
	BOOL			Result;

	newAddr = 0x80 | addr;

	memset(&WriteBuffer, 0, Capabilities.OutputReportByteLength+1);

	WriteBuffer[0] = 0x00;
	WriteBuffer[1] = cmd;
	WriteBuffer[2] = newAddr;

	Result = WriteFile(handle, &WriteBuffer, Capabilities.OutputReportByteLength, &BytesWritten, NULL);

	if(Result != NULL)
	{
		memset(&ReadBuffer, 0, Capabilities.InputReportByteLength+1);
		ReadBuffer[0] = 0x00;
	
		ReadFile(handle, &ReadBuffer, Capabilities.InputReportByteLength, &NumberOfBytesRead, NULL);
		return ReadBuffer[3];
	}
	else
		return 0;
}

/*
Run calibration-function to set new offset of SMB320
*/
void CCalibrationDlg::OnBnClickedCalibrate()
{
	KillTimer(ID_LOOPTIME);

	WriteData(DevHandle[1], 0x82, 0x0A, 0x10); //open "ee-w" (EEPROM)

	if(MessageBox(_T("You will start 'Auto Adjustment'."), _T("WARNING"), MB_OKCANCEL | MB_ICONQUESTION) == IDOK)
	{
		WriteOffset(DevHandle[1], 'X', 0, 0);
		ReadAxes(DevHandle[1]);

		WriteOffset(DevHandle[1], 'Y', 0, 0);
		ReadAxes(DevHandle[1]);

		WriteOffset(DevHandle[1], 'Z', 0, 0);
		ReadAxes(DevHandle[1]);

		ReadCalib();
	}

	WriteData(DevHandle[1], 0x82, 0x0A, 0x00); //close "ee-w" (EEPROM)

	SetTimer(ID_LOOPTIME, 50, NULL);
}

/*
Convert first two chars from CString into hex-value
*/
UCHAR CCalibrationDlg::ConvertString(CString value)
{
	int	ret, ret1, exec;
	ret = 0;
	ret1 = 0;
	exec = 0;
	wchar_t newvalue[2];

	for(int h=0; h<2; h++)
		newvalue[h] = value.GetAt(h);

	switch(newvalue[1])
	{
	case '0':
		ret = 0;
		break;
	case '1':
		ret = 1;
		break;
	case '2':
		ret = 2;
		break;
	case '3':
		ret = 3;
		break;
	case '4':
		ret = 4;
		break;
	case '5':
		ret = 5;
		break;
	case '6':
		ret = 6;
		break;
	case '7':
		ret = 7;
		break;
	case '8':
		ret = 8;
		break;
	case '9':
		ret = 9;
		break;
	case 'A':
		ret = 10;
		break;
	case 'B':
		ret = 11;
		break;
	case 'C':
		ret = 12;
		break;
	case 'D':
		ret = 13;
		break;
	case 'E':
		ret = 14;
		break;
	case 'F':
		ret = 15;
		break;
	}

	switch(newvalue[0])
	{
	case '0':
		ret1 = 0;
		break;
	case '1':
		ret1 = 16;
		break;
	case '2':
		ret1 = 32;
		break;
	case '3':
		ret1 = 48;
		break;
	case '4':
		ret1 = 64;
		break;
	case '5':
		ret1 = 80;
		break;
	case '6':
		ret1 = 96;
		break;
	case '7':
		ret1 = 112;
		break;
	case '8':
		ret1 = 128;
		break;
	case '9':
		ret1 = 144;
		break;
	case 'A':
		ret1 = 160;
		break;
	case 'B':
		ret1 = 176;
		break;
	case 'C':
		ret1 = 192;
		break;
	case 'D':
		ret1 = 208;
		break;
	case 'E':
		ret1 = 224;
		break;
	case 'F':
		ret1 = 240;
		break;
	}

	exec = ret + ret1;

	return exec;
}


/*
Read offset-register
*/
void CCalibrationDlg::ReadCalib()
{
	UpdateData(TRUE);
	CString reg, lsb, msb, calc;
	CString offset;
	UCHAR tLSB, tMSB;
	int iDouble;
	UCHAR LSB[3] = {0x16, 0x17, 0x18};
	UCHAR MSB[3] = {0x1A, 0x1B, 0x1C};
	char axe[3] = {'X', 'Y', 'Z'};

	mList.DeleteAllItems();

	WriteData(DevHandle[1], 0x82, 0x0A, 0x10);

	for(int i=0; i<3; i++)
	{
		reg.Format(_T("%C"), axe[i]);

		tLSB = ReadData(DevHandle[1], 0x82, LSB[i]);
		tMSB = ReadData(DevHandle[1], 0x82, MSB[i]);

		iDouble = CalcOffset(tLSB, tMSB);

		calc.Format(_T("%d"), iDouble);
		offset.Format(_T("0x%.3X"), iDouble);

		mList.InsertItem(i, reg, NULL); //register
		mList.SetItemText(i, 1, offset); //Offset
		mList.SetItemText(i, 2, calc); //readable value
	}

	WriteData(DevHandle[1], 0x82, 0x0A, 0x00);
	UpdateData(FALSE);

}

/*
Read acc-register
*/
void CCalibrationDlg::ReadAxes(HANDLE handle)
{
	CString reg, lsb, msb, calc;

	UCHAR tLSB, tMSB;
	short iDouble;
	UCHAR LSB[3] = {0x02, 0x04, 0x06};
	UCHAR MSB[3] = {0x03, 0x05, 0x07};
	char axe[3] = {'X', 'Y', 'Z'};

	CString values[3];

	HidD_FlushQueue(handle); //clear Hid-Queue

	for(int i=0; i<3; i++)
	{
		reg.Format(_T("%C"), axe[i]);

		tLSB = ReadData(handle, 0x82, LSB[i]);
		tMSB = ReadData(handle, 0x82, MSB[i]);

		iDouble = CalcMsbLsb(tLSB, tMSB);
		calc.Format(_T("%d"), iDouble);
		values[i] = calc;
	}

	GetDlgItem(IDC_STATIC_X)->SetWindowTextW(values[0]);
	GetDlgItem(IDC_STATIC_Y)->SetWindowTextW(values[1]);
	GetDlgItem(IDC_STATIC_Z)->SetWindowTextW(values[2]);
}

/*
Calculate acc-value from MB and LSB into short
*/
short CCalibrationDlg::CalcMsbLsb(UCHAR lsb, UCHAR msb)
{
	short erg;
	short LSB, MSB, EXEC;
	short TEMP = 0x0000;

	EXEC = (msb & 0x80) << 8;
	EXEC = EXEC & 0x8000;

	/*Calcluate nagative value*/
	if(EXEC & 0x8000)
		EXEC = EXEC | 0x7C00;

	MSB = msb << 2;
	MSB = MSB & 0x03FC;
	LSB = (lsb & 0xC0) >> 6;
	LSB = LSB & 0x0003;

	erg = MSB | LSB | EXEC;

	return erg;
}

/*
Calculate offset-value from MB and LSB into short
*/
short CCalibrationDlg::CalcOffset(UCHAR lsb, UCHAR msb)
{
	short erg;
	short LSB, MSB;

	MSB = msb << 2;
	MSB = MSB & 0x03FC;
	LSB = (lsb & 0xC0) >> 6;
	LSB = LSB & 0x0003;

	erg = MSB | LSB;

	return erg;
}

/*
Calculate short to get difference
*/
void CCalibrationDlg::DiffMsbLsb(short value)
{
	UCHAR LSB, MSB;
	ULONG ALL;
	CString temp;

	ALL = value;

	LSB = ((value & 0x003) << 6) & 0xC0;
	MSB = ((value & 0x3FC) >> 2) & 0xFF;

	iMsbLsb[0] = LSB;
	iMsbLsb[1] = MSB;
}

/*
Main-function for calibration
*/
BOOL CCalibrationDlg::WriteOffset(HANDLE handle, char axe, int gforce, unsigned short z_ref)
{
	/*
	Allowed Values
	
	1 LSB -> 8.25 Pts Offset

	0x00 -> 0 -> 00000000
	0x10 -> 1 -> 01000000
	0x20 -> 2 -> 10000000
	0x30 -> 3 -> 11000000

	Offset-Range: -256 ... +256
	Offset-Zero @ 2G (0;0;256) (x;y;z)
	*/

	short dif;
	short off;
	short reference;

	double ref;

	UCHAR ACC_MSB, ACC_LSB;
	UCHAR OFF_MSB, OFF_LSB, OFF_GAIN;

	UCHAR offset_lsb;
	UCHAR offset_msb;
	UCHAR set_offset;
	ACC_OFFSET acc_value;

	/*Set stepping for calibrate*/
	short stepping[3] = {8,4,2}; //NOT IN USE

	/*
	For more detail of reference take  look into the datasheet (page 9)
	Default for 2g is (0;0;256)	
	*/
	short reference_x[6] = {0,0,0,0,256,-256};
	short reference_y[6] = {0,0,256,-256,0,0};
	short reference_z[6] = {256,-256,0,0,0,0};

	/*set var with right values*/
	switch(axe)
	{
	case 'x':
	case 'X':
		offset_lsb = 0x16;
		offset_msb = 0x1A;
		acc_value.lsb = 0x02;
		acc_value.msb = 0x03;
		reference = reference_x[z_ref];
		break;

	case 'y':
	case 'Y':
		offset_lsb = 0x17;
		offset_msb = 0x1B;
		acc_value.lsb = 0x04;
		acc_value.msb = 0x05;
		reference = reference_y[z_ref];
		break;

	case 'z':
	case 'Z':
		offset_lsb = 0x18;
		offset_msb = 0x1C;
		acc_value.lsb = 0x06;
		acc_value.msb = 0x07;
		reference = reference_z[z_ref];
		break;
	}

	HidD_FlushQueue(handle); //Clear Hid-Buffer to prevent corupted data
	WriteData(handle, 0x82, 0x0A, 0x10); //Open Offset-Register

	/*save GAIN*/
	OFF_LSB = ReadData(handle, 0x82, offset_lsb);
	OFF_GAIN = OFF_LSB & 0x3F;

	HidD_FlushQueue(handle); //Clear Hid-Buffer to prevent corupted data

	do
	{
		dif = 0;
		ref = 0;
		off = 0;
					
		ACC_LSB = ReadData(handle, 0x82, acc_value.lsb);
		ACC_MSB = ReadData(handle, 0x82, acc_value.msb);
		dif = CalcMsbLsb(ACC_LSB, ACC_MSB); //get Acc -> double-wert

		OFF_LSB = ReadData(handle, 0x82, offset_lsb);
		OFF_MSB = ReadData(handle, 0x82, offset_msb);
		off = CalcMsbLsb(OFF_LSB, OFF_MSB); //get Offset -> double-wert
		

		/*division with 8 (for 2G & >25Hz*/
		ref = floor((dif - reference)/8.00);

		if ((dif > (reference + 4)) || (dif < (reference - 4)))  // is calibration needed?
		{
			if((dif < 8) && (dif > 0)) //acc > +0 and < +8
				DiffMsbLsb(off -1);
			else if((dif > -8) && (dif < 0)) //acc < -0 and > -8
				DiffMsbLsb(off +1);
			else
				DiffMsbLsb(off - (short)ref); //if acc > -8 or < +8

			WriteData(handle, 0x82, offset_lsb | 0x00, (UCHAR) iMsbLsb[0]);
			WriteData(handle, 0x82, offset_msb | 0x00, (UCHAR) iMsbLsb[1]);

			Sleep(50);

			/*write GAIN into LSB to restore old GAIN-Value*/
			OFF_LSB = ReadData(handle, 0x82, offset_lsb);
			set_offset = OFF_LSB | OFF_GAIN;
			WriteData(handle, 0x82, offset_lsb | 0x00, set_offset);

			Sleep(50); //Sleep because set register need short time to set
		}
		else
			break;
	}while(ref < 1);

	/*write offset from image -> eeprom*/

	OFF_LSB = 0;
	OFF_MSB = 0;

	OFF_LSB = ReadData(handle, 0x82, offset_lsb);
	OFF_MSB = ReadData(handle, 0x82, offset_msb);

	Sleep(50);

	WriteData(handle, 0x82, offset_lsb | 0x20, OFF_LSB);
	Sleep(50);
	WriteData(handle, 0x82, offset_msb | 0x20, OFF_MSB);
	Sleep(200);

	return 0;
}

void CCalibrationDlg::OnClose()
{
	KillTimer(ID_LOOPTIME);
	if(dBool == TRUE)
		WriteData(DevHandle[1], 0x02, 0x00, 0x00); //exit command-mode from jw / mw
	CDialog::OnClose();
}

/*
Enumerate all HID-Devices after a new plug-in / plug-off
*/
LRESULT CCalibrationDlg::OnDeviceChange(WPARAM wParam, LPARAM lParam)
{
	
	cBool = FALSE;
	dBool = FALSE;
	mList.DeleteAllItems();
	cStatusMsg.SetWindowTextW(_T("No Device Found"));
	cSerial.SetWindowTextW(_T("- - -"));

	GetDlgItem(IDC_STATIC_X)->SetWindowTextW(_T("-1"));
	GetDlgItem(IDC_STATIC_Y)->SetWindowTextW(_T("-1"));
	GetDlgItem(IDC_STATIC_Z)->SetWindowTextW(_T("-1"));

	ConnectToHid(0, 0x07C0);
	HidD_FlushQueue(DevHandle[1]); //Clear HID-Queue from "ghosts"

	if(dBool == TRUE)
	{
		ReadCalib();
		Sleep(100);
		SetTimer(ID_LOOPTIME, 50, NULL);
	}
	return 0;
}

HBRUSH CCalibrationDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	CString test;
	int limit;

	if(pWnd->GetDlgCtrlID() == IDC_STATUS)
    {
		if(cBool == TRUE)
			pDC->SetTextColor(RGB(0, 160, 0));
		else
			pDC->SetTextColor(RGB(160, 0, 0));
    }

	if(pWnd->GetDlgCtrlID() == IDC_STATIC_X)
	{
		GetDlgItem(IDC_STATIC_X)->GetWindowTextW(test);
		
		limit = _ttoi(test);

		if((limit > 4) || (limit < - 4))
			pDC->SetTextColor(RGB(128, 0, 0));
		else
			pDC->SetTextColor(RGB(0, 128, 0));
	}

	if(pWnd->GetDlgCtrlID() == IDC_STATIC_Y)
	{
		GetDlgItem(IDC_STATIC_Y)->GetWindowTextW(test);
		
		limit = _ttoi(test);

		if((limit > 4) || (limit < - 4))
			pDC->SetTextColor(RGB(128, 0, 0));
		else
			pDC->SetTextColor(RGB(0, 128, 0));
	}

	if(pWnd->GetDlgCtrlID() == IDC_STATIC_Z)
	{
		GetDlgItem(IDC_STATIC_Z)->GetWindowTextW(test);
		
		limit = _ttoi(test);

		if((limit > 264) || (limit < - 264))
			pDC->SetTextColor(RGB(128, 0, 0));
		else
			pDC->SetTextColor(RGB(0, 128, 0));
	}


	return hbr;
}

void CCalibrationDlg::OnFileExit()
{
	KillTimer(ID_LOOPTIME);
	if(dBool == TRUE)
		WriteData(DevHandle[1], 0x02, 0x00, 0x00); //exit command-mode from jw / mw
	OnOK();
}


void CCalibrationDlg::OnFunctionsManualgain()
{
	UpdateData(TRUE);
	cBool = TRUE;
	CString temp;
	UCHAR gains[3];
	UCHAR diff_gain[3];
	/*Set gain to dialog (&0x3F)*/


	WriteData(DevHandle[1], 0x82, 0x0A, 0x10); //open ee_w (EEPROM)
	
	gains[0] = (ReadData(DevHandle[1], 0x82, 0x16) & 0x3F);
	temp.Format(_T("%.2X"), gains[0]);
	dGain.sGainX = temp;

	gains[1] = (ReadData(DevHandle[1], 0x82, 0x17) & 0x3F);
	temp.Format(_T("%.2X"), gains[1]);
	dGain.sGainY = temp;

	gains[2] = (ReadData(DevHandle[1], 0x82, 0x18) & 0x3F);
	temp.Format(_T("%.2X"), gains[2]);
	dGain.sGainZ = temp;

	dGain.DoModal();

	diff_gain[0] = ConvertString(dGain.sGainX);
	diff_gain[1] = ConvertString(dGain.sGainY);
	diff_gain[2] = ConvertString(dGain.sGainZ);

	/*
	 * Write new GAIN into Image-Register
	 * IMPORTANT: GAIN will be set from Bosch Industries an will not be changed in EEPROM from us
     *            This is only to show how GAIN works and if GAIN is wrong wicht steps to go to
	 *			  recalibrate it.
	*/            
	if(diff_gain[0] != gains[0])
	{
		UCHAR LSB, NEW_LSB;

		LSB = ReadData(DevHandle[1], 0x82, 0x16);
		LSB = LSB & 0xC0;

		NEW_LSB = LSB | diff_gain[0];

		WriteData(DevHandle[1], 0x82, 0x16, NEW_LSB);
	}

	if(diff_gain[1] != gains[1])
	{
		UCHAR LSB, NEW_LSB;

		LSB = ReadData(DevHandle[1], 0x82, 0x17);
		LSB = LSB & 0xC0;

		NEW_LSB = LSB | diff_gain[1];

		WriteData(DevHandle[1], 0x82, 0x17, NEW_LSB);
	}


	if(diff_gain[2] != gains[2])
	{
		UCHAR LSB, NEW_LSB;

		LSB = ReadData(DevHandle[1], 0x82, 0x18);
		LSB = LSB & 0xC0;

		NEW_LSB = LSB | diff_gain[2];

		WriteData(DevHandle[1], 0x82, 0x18, NEW_LSB);
	}

	WriteData(DevHandle[1], 0x82, 0x0A, 0x00); //close ee_w (EEPROM)
	cBool = FALSE;
}

void CCalibrationDlg::OnTimer(UINT_PTR nIDEvent)
{
	ReadAxes(DevHandle[1]);

	CDialog::OnTimer(nIDEvent);
}
