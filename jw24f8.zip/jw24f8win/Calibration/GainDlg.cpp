// GainDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "Calibration.h"
#include "CalibrationDlg.h"
#include "GainDlg.h"


// CGainDlg-Dialogfeld

IMPLEMENT_DYNAMIC(CGainDlg, CDialog)

CGainDlg::CGainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGainDlg::IDD, pParent)
	, sGainX(_T(""))
	, sGainY(_T(""))
	, sGainZ(_T(""))
{

}

CGainDlg::~CGainDlg()
{
}

void CGainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_GAIN_X, sGainX);
	DDX_Text(pDX, IDC_GAIN_Y, sGainY);
	DDX_Text(pDX, IDC_GAIN_Z, sGainZ);
}


BEGIN_MESSAGE_MAP(CGainDlg, CDialog)
	ON_BN_CLICKED(IDC_SETGAIN, &CGainDlg::OnBnClickedSetgain)
END_MESSAGE_MAP()


// CGainDlg-Meldungshandler

void CGainDlg::OnBnClickedSetgain()
{
	OnOK();
}
