#pragma once


// CGainDlg-Dialogfeld

class CGainDlg : public CDialog
{
	DECLARE_DYNAMIC(CGainDlg)

public:
	CGainDlg(CWnd* pParent = NULL);   // Standardkonstruktor
	virtual ~CGainDlg();

// Dialogfelddaten
	enum { IDD = IDD_GAINDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung

	DECLARE_MESSAGE_MAP()
public:
	CString sGainX;
	CString sGainY;
	CString sGainZ;
	afx_msg void OnBnClickedSetgain();
};
