//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Calibration.rc
//
#define ID_LOOPTIME                     1
#define IDD_CALIBRATION_DIALOG          9
#define IDD_KALIBRIERUNG_DIALOG         102
#define IDD_GAINDLG                     103
#define IDR_MAINFRAME                   128
#define IDR_MENU                        129
#define IDB_BITMAP1                     133
#define IDC_CONNECT                     1000
#define IDC_CALIBRATE                   1001
#define IDC_CHECK_X                     1002
#define IDC_CHECK_Y                     1003
#define IDC_CHECK_Z                     1004
#define IDC_OFFSET_X_MSB                1005
#define IDC_OFFSET_Y_MSB                1006
#define IDC_OFFSET_Z_MSB                1007
#define IDC_CHECK_T                     1008
#define IDC_OFFSET_T_MSB                1009
#define IDC_STATUS                      1010
#define IDC_LIST                        1011
#define IDC_READCALIB                   1012
#define IDC_ACHSWERTE                   1013
#define IDC_READAXES                    1014
#define IDC_OFFSET_X_LSB                1015
#define IDC_OFFSET_Y_LSB                1016
#define IDC_OFFSET_Z_LSB                1017
#define IDC_OFFSET_T_LSB                1018
#define IDC_RADIO                       1019
#define IDC_RADIO1                      1019
#define IDC_RADIO2                      1020
#define IDC_CHECK_AUTO                  1023
#define IDC_EDIT1                       1025
#define IDC_GAIN_X                      1025
#define IDC_EDIT2                       1026
#define IDC_GAIN_Y                      1026
#define IDC_EDIT3                       1027
#define IDC_GAIN_Z                      1027
#define IDC_BUTTON1                     1028
#define IDC_SETGAIN                     1028
#define IDC_STATIC_X                    1029
#define IDC_STATIC_Y                    1030
#define IDC_STATIC_Z                    1031
#define IDC_STATIC_SERIAL               1032
#define IDC_STATIC_X2                   1033
#define IDC_STATIC_Y2                   1034
#define IDC_STATIC_Z2                   1035
#define IDC_STATIC_X3                   1036
#define ID_FILE_CONNECT                 32771
#define ID_FILE_EXIT                    32772
#define ID_FUNCTIONS_AUTOADJUSTMENT     32773
#define ID_FUNCTIONS_MANUALGAIN         32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
