// CalibrationDlg.h : Headerdatei
//

#pragma once

extern "C" { 
#include "hidsdi.h" 
#include "setupapi.h"
}


// CKalibrierungDlg-Dialogfeld
#include "afxcmn.h"
#include "afxwin.h"
#include "gaindlg.h"



// CCalibrationDlg-Dialogfeld
class CCalibrationDlg : public CDialog
{
// Konstruktion
public:
	CCalibrationDlg(CWnd* pParent = NULL);	// Standardkonstruktor

// Dialogfelddaten
	enum { IDD = IDD_CALIBRATION_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung


// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Funktionen f�r die Meldungstabellen
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCalibrate();
	afx_msg void OnClose();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnFileExit();
	afx_msg void OnFunctionsManualgain();
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	void ConnectToHid(ULONG productID, ULONG vendorID);
	void GetPreparsedData(HANDLE handle);
	void ReadCalib();
	void ReadAxes(HANDLE handle);
	void DiffMsbLsb(short value);

	short CalcMsbLsb(UCHAR lsb, UCHAR msb);
	short CalcOffset(UCHAR lsb, UCHAR msb);

	BOOL WriteOffset(HANDLE handle, char axe, int gforce, unsigned short z_ref);
	BOOL WriteData(HANDLE handle, UCHAR cmd, UCHAR addr, UCHAR data);

	LRESULT OnDeviceChange(WPARAM wParam, LPARAM lParam);

	UCHAR ConvertString(CString value);
	UCHAR ReadData(HANDLE handle, UCHAR cmd, UCHAR addr);

	CString GetSerialNumber(HANDLE handle);

	HIDP_CAPS Capabilities;
	HANDLE DeviceHandle;
	HANDLE DevHandle[2];

	typedef struct ACC_OFFSET {
		UCHAR lsb;
		UCHAR msb;
	} ACC_OFFSET;


	BOOL dBool; //Set GetHid-Continue
	BOOL cBool; //Set Devicetext

	CListCtrl mList;
	CStatic cStatusMsg;
	CStatic cSerial;

	unsigned short iMsbLsb[2];

	CGainDlg dGain;

};
