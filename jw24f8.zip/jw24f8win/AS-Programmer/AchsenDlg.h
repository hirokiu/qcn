#pragma once
#include "afxwin.h"


// CAchsenDlg-Dialogfeld

class CAchsenDlg : public CDialog
{
	DECLARE_DYNAMIC(CAchsenDlg)

public:
	CAchsenDlg(CWnd* pParent = NULL);   // Standardkonstruktor
	virtual ~CAchsenDlg();

// Dialogfelddaten
	enum { IDD = IDD_ACHSENDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung

	DECLARE_MESSAGE_MAP()
public:
	void GetTimerData(short value, char axe);
	CStatic cStaticX;
	CStatic cStaticY;
	CStatic cStaticZ;	
	
	CStatic cValueX;
	CStatic cValueY;
	CStatic cValueZ;
};
