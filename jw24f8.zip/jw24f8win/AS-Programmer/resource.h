//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AS-Programmer.rc
//
#define IDC_LOOPTIME                    1
#define IDD_JWFORCE8_DIALOG             102
#define IDD_ASPROGRAMMER_DIALOG         102
#define IDD_ACHSENDLG                   105
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDR_MENU1                       130
#define IDB_EXIT                        132
#define IDB_BGREEN                      138
#define IDB_BGREY                       139
#define IDC_WRITEDATA                   1000
#define IDC_READDATA                    1003
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1005
#define IDC_RADIO3                      1006
#define IDC_RADIO5                      1008
#define IDC_RADIO6                      1009
#define IDC_RADIO7                      1010
#define IDC_RADIO8                      1011
#define IDC_RADIO9                      1015
#define IDC_RADIO10                     1016
#define IDC_RADIO11                     1017
#define IDC_RADIO4                      1019
#define IDC_RADIO12                     1020
#define IDC_RADIO13                     1021
#define IDC_RADIO14                     1025
#define IDC_RADIO15                     1026
#define IDC_RADIO16                     1027
#define IDC_ENABLE_LG                   1028
#define IDC_ENABLE_HG                   1029
#define IDC_ENABLE_INT                  1030
#define IDC_ANYMOTION                   1031
#define IDC_ALERT                       1032
#define IDC_LATCH_INT                   1033
#define IDC_RADIO17                     1034
#define IDC_RADIO18                     1035
#define IDC_RADIO19                     1036
#define IDC_RADIO20                     1037
#define IDC_RADIO21                     1038
#define IDC_RADIO22                     1039
#define IDC_RADIO23                     1040
#define IDC_RADIO24                     1041
#define IDC_RADIO25                     1042
#define IDC_RADIO26                     1043
#define IDC_RADIO27                     1044
#define IDC_RADIO28                     1045
#define IDC_NEWDATA_INT                 1046
#define IDC_SHADOW_DIS                  1048
#define IDC_EDITLGTHRES                 1049
#define IDC_EDITLGDUR                   1050
#define IDC_EDITHGDUR                   1051
#define IDC_EDITHGTHRES                 1052
#define IDC_EDITAM                      1053
#define IDC_EDITCUSTOMER1               1054
#define IDC_EDITCUSTOMER2               1055
#define IDC_LGHYST                      1056
#define IDC_HGHYST                      1058
#define IDC_REPORTLIST                  1059
#define IDC_STATUSMSG                   1064
#define IDC_DEVICE                      1065
#define IDC_STATUSBOX                   1066
#define IDC_SERIALNO                    1067
#define IDC_PROGRESS1                   1073
#define IDC_PROGRESS                    1073
#define IDC_STATIC_VERSION              1074
#define IDC_RADIO31                     1075
#define IDC_RADIO32                     1076
#define IDC_RADIO33                     1077
#define IDC_STATIC_B1                   1083
#define IDC_STATIC_B2                   1084
#define IDC_STATIC_B3                   1085
#define IDC_STATIC_B4                   1086
#define IDC_STATIC_B5                   1087
#define IDC_STATIC_B6                   1088
#define IDC_STATICX                     1089
#define IDC_STATICY                     1090
#define IDC_STATICZ                     1091
#define IDC_STATIC_VX                   1092
#define IDC_STATIC_VY                   1093
#define IDC_STATIC_VZ                   1094
#define IDC_ANYMOTIONDURATION           1095
#define IDC_BANDWIDTH                   1096
#define IDC_RANGE                       1097
#define IDC_BANDWIDTH2                  1098
#define IDC_REGISTER                    1098
#define ID_DATEI_OPEN                   32771
#define ID_DATEI_CLOSE                  32772
#define ID_DATEI_SAVE                   32773
#define ID_DATEI_EXIT                   32774
#define ID_JW24F8_CONNECT               32775
#define ID_JW24F8_DETAILS               32776
#define ID_FUNCTIOS_SLEEP               32777
#define ID_FUNCTIOS_SOFTRESET           32778
#define ID_FUNCTIOS_SELFTEST1           32779
#define ID_FUNCTIOS_UPDATEIMAGE         32780
#define ID_FUNCTIOS_RESETINTERUPT       32781
#define ID_FUNCTIOS_SELFTEST_0          32782
#define ID_FUNCTIOS_SELFTEST0           32783
#define ID_Menu                         32784
#define ID_FILE_CONNECT                 32785
#define ID_FUNCTIONS_AXE                32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1096
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
