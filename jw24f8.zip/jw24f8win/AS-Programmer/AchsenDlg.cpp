// AchsenDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "AS-Programmer.h"
#include "AchsenDlg.h"


// CAchsenDlg-Dialogfeld

IMPLEMENT_DYNAMIC(CAchsenDlg, CDialog)

CAchsenDlg::CAchsenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAchsenDlg::IDD, pParent)
{

}

CAchsenDlg::~CAchsenDlg()
{
}

void CAchsenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATICX, cStaticX);
	DDX_Control(pDX, IDC_STATIC_VX, cValueX);
	DDX_Control(pDX, IDC_STATIC_VY, cValueY);
	DDX_Control(pDX, IDC_STATIC_VZ, cValueZ);
	DDX_Control(pDX, IDC_STATICY, cStaticY);
	DDX_Control(pDX, IDC_STATICZ, cStaticZ);
}


BEGIN_MESSAGE_MAP(CAchsenDlg, CDialog)
	ON_WM_CLOSE()
END_MESSAGE_MAP()


// CAchsenDlg-Meldungshandler

void CAchsenDlg::GetTimerData(short value, char axe)
{
	CString temp;

	temp.Format(_T("%d"), value);

	if(axe == 'X')
		cValueX.SetWindowTextW(temp);
	if(axe == 'Y')
		cValueY.SetWindowTextW(temp);
	if(axe == 'Z')
		cValueZ.SetWindowTextW(temp);
}
