// AS-ProgrammerDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "AS-Programmer.h"
#include "AS-ProgrammerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CASProgrammerDlg-Dialogfeld

CASProgrammerDlg::CASProgrammerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CASProgrammerDlg::IDD, pParent)
	, mRange(0)
	, mBand(0)
	, mCounterLG(0)
	, mCounterHG(0)
	, mAnyMotion(0)
	, mRegister(0)
	, mAM_AL(0)
	, mEnableLG(FALSE)
	, mEnableHG(FALSE)
	, mAdvInt(FALSE)
	, Reg_0F(_T(""))
	, Reg_0E(_T(""))
	, Reg_0D(_T(""))
	, Reg_0C(_T(""))
	, mCust1(_T(""))
	, mCust2(_T(""))
	, mLGdur(_T(""))
	, mLGthres(_T(""))
	, mHGdur(_T(""))
	, mHGthres(_T(""))
	, mAMthres(_T(""))
	, mLGhyst(0)
	, mHGhyst(0)
	, cBool(false)
	, mBool(false)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CASProgrammerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Radio(pDX, IDC_RADIO17, mCounterLG);
	DDX_Radio(pDX, IDC_RADIO21, mCounterHG);
	DDX_Radio(pDX, IDC_RADIO31, mAM_AL);

	DDX_Check(pDX, IDC_ENABLE_LG, mEnableLG);
	DDX_Check(pDX, IDC_ENABLE_HG, mEnableHG);
	DDX_Check(pDX, IDC_ENABLE_INT, mAdvInt);

	DDX_Text(pDX, IDC_EDITCUSTOMER1, mCust1);
	DDX_Text(pDX, IDC_EDITCUSTOMER2, mCust2);
	DDX_Text(pDX, IDC_EDITLGDUR, mLGdur);
	DDX_Text(pDX, IDC_EDITLGTHRES, mLGthres);
	DDX_Text(pDX, IDC_EDITHGDUR, mHGdur);
	DDX_Text(pDX, IDC_EDITHGTHRES, mHGthres);
	DDX_Text(pDX, IDC_EDITAM, mAMthres);

	DDX_CBIndex(pDX, IDC_LGHYST, mLGhyst);
	DDX_CBIndex(pDX, IDC_HGHYST, mHGhyst);
	DDX_CBIndex(pDX, IDC_ANYMOTIONDURATION, mAnyMotion);
	DDX_CBIndex(pDX, IDC_REGISTER, mRegister);
	DDX_CBIndex(pDX, IDC_RANGE, mRange);
	DDX_CBIndex(pDX, IDC_BANDWIDTH, mBand);

	DDX_Control(pDX, IDC_REPORTLIST, mRepList);
	DDX_Control(pDX, IDC_STATUSMSG, cStatusMsg);
	DDX_Control(pDX, IDC_DEVICE, cDevice);
	DDX_Control(pDX, IDC_SERIALNO, cSerialNo);
	DDX_Control(pDX, IDC_STATIC_B1, cBitmap[0]);
	DDX_Control(pDX, IDC_STATIC_B2, cBitmap[1]);
	DDX_Control(pDX, IDC_STATIC_B3, cBitmap[2]);
	DDX_Control(pDX, IDC_STATIC_B4, cBitmap[3]);
	DDX_Control(pDX, IDC_STATIC_B5, cBitmap[4]);
	DDX_Control(pDX, IDC_STATIC_B6, cBitmap[5]);
}

BEGIN_MESSAGE_MAP(CASProgrammerDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_DEVICECHANGE, &CASProgrammerDlg::JwGetDevice) //Find devices automaticly
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_WRITEDATA, &CASProgrammerDlg::OnBnClickedWritedata)
	ON_BN_CLICKED(IDC_READDATA, &CASProgrammerDlg::OnBnClickedReaddata)
	ON_WM_CLOSE()
	ON_COMMAND(ID_DATEI_EXIT, &CASProgrammerDlg::OnDateiExit)
	ON_COMMAND(ID_DATEI_SAVE, &CASProgrammerDlg::OnDateiSave)
	ON_COMMAND(ID_DATEI_OPEN, &CASProgrammerDlg::OnDateiOpen)
	ON_COMMAND(ID_FUNCTIOS_SOFTRESET, &CASProgrammerDlg::OnFunctiosSoftreset)
	ON_COMMAND(ID_FUNCTIOS_SELFTEST0, &CASProgrammerDlg::OnFunctiosSelftest0)
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_COMMAND(ID_FUNCTIONS_AXE, &CASProgrammerDlg::OnFunctionsAxe)
END_MESSAGE_MAP()


// CASProgrammerDlg-Meldungshandler

BOOL CASProgrammerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	/*Create colums for listing register*/
	mRepList.InsertColumn(0, _T("Order"), LVCFMT_LEFT, 50);
	mRepList.InsertColumn(1, _T("Register"), LVCFMT_LEFT, 60);
	mRepList.InsertColumn(2, _T("Value"), LVCFMT_LEFT, 50);
	mRepList.InsertColumn(3, _T("Check"), LVCFMT_LEFT, 50);
	mRepList.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	/*Clear all handles with NULL*/
	cBool = FALSE;
	HidHandle[0] = NULL;
	HidHandle[1] = NULL;
	DeviceHandle = NULL;

	/*Set alle static-symbols to "---"*/
	GetDlgItem(IDC_WRITEDATA)->EnableWindow(FALSE);
	GetDlgItem(IDC_READDATA)->EnableWindow(FALSE);
	cStatusMsg.SetWindowText(_T("No compatible device found"));
	cDevice.SetWindowText(_T("- - - - -"));
	cSerialNo.SetWindowText(_T("- - - - -"));

	/*Create font for 2nd dialog and create 2nd dialog*/
	cFont.CreateFontW(32, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0, DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, _T("Arial"));
	dAxes.Create(IDD_ACHSENDLG, this);

	/*Connect to all USB-Devices and search especialy for JW / MW*/
	memset(&gRegRead, 0x00, 12);
	mRepList.DeleteAllItems();
	JwGetHandle(0, 0x07C0);

	/*Show menu and set*/
	cMenu.LoadMenu(IDR_MENU1);
	SetMenu(&cMenu);

	if(HidHandle[1] == NULL)
	{
		EnableMenuItem(cMenu, ID_FUNCTIOS_SELFTEST0, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		EnableMenuItem(cMenu, ID_FUNCTIOS_SOFTRESET, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		EnableMenuItem(cMenu, ID_FUNCTIONS_AXE, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

		JwSetDialog();
	}
	else
	{
		OnBnClickedReaddata();
	}


	BitBuffer.DeleteObject();
	BitBuffer.LoadBitmapW(IDB_BGREY);

	for(int j=0; j<6; j++)
		cBitmap[j].SetBitmap(BitBuffer);

	UpdateData(FALSE);

	return TRUE;
}


void CASProgrammerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CASProgrammerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

HBRUSH CASProgrammerDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if(pWnd->GetDlgCtrlID() == IDC_STATUSMSG)
    {
		if(cBool == 1)
			pDC->SetTextColor(RGB(0, 160, 0)); //Status GREEN
		else if(cBool == 2)
			pDC->SetTextColor(RGB(240,130,30)); //Status ORANGE
		else
			pDC->SetTextColor(RGB(160, 0, 0)); //Status RED
    }

	if(pWnd->GetDlgCtrlID() == IDC_STATIC_VERSION)
    {
		pDC->SetTextColor(RGB(160, 160, 160)); //Color for Version: GREY
    }

	return hbr;
}

/*
Auto plugin-function to detect new USB-Devices
*/
LRESULT CASProgrammerDlg::JwGetDevice(WPARAM wParam, LPARAM lParam)
{
	/*Disable Menu-Buttons for prevent errors*/
	EnableMenuItem(cMenu, ID_FUNCTIOS_SELFTEST0, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	EnableMenuItem(cMenu, ID_FUNCTIOS_SOFTRESET, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	EnableMenuItem(cMenu, ID_FUNCTIONS_AXE, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

	KillTimer(IDC_LOOPTIME);

	/*Clear all handles, set statics to "---" and disable buttons*/
	cBool = 0;
	GetDlgItem(IDC_WRITEDATA)->EnableWindow(FALSE);
	GetDlgItem(IDC_READDATA)->EnableWindow(FALSE);
	cStatusMsg.SetWindowTextW(_T("No compatible device found"));
	cDevice.SetWindowTextW(_T("- - - - -"));
	cSerialNo.SetWindowTextW(_T("- - - - -"));
	HidHandle[0] = NULL;
	HidHandle[1] = NULL;
	DeviceHandle = NULL;
		
	memset(&gRegRead, 0x00, 12);
	mRepList.DeleteAllItems();
	JwGetHandle(0, 0x07C0);

	if(HidHandle[1] != NULL)
	{
		EnableMenuItem(cMenu, ID_FUNCTIOS_SELFTEST0, MF_ENABLED);
		EnableMenuItem(cMenu, ID_FUNCTIOS_SOFTRESET, MF_ENABLED);
		EnableMenuItem(cMenu, ID_FUNCTIONS_AXE, MF_ENABLED);
		OnBnClickedReaddata();
	}
	else
		JwSetDialog();
	
	return LRESULT();
}
/*
Get serialnumber from JoyWarrior / MouseWarrior
*/
CString CASProgrammerDlg::JwGetSerialNumber(HANDLE handle)
{
	WCHAR sn[32];
	CString	serial;
	
	memset(&sn, 0, 32);
	HidD_GetSerialNumberString(handle, &sn, 32); 

	serial.Format(_T("%s"), &sn[0]);
	return serial;
}


BOOL CASProgrammerDlg::JwGetHandle(ULONG productID, ULONG vendorID)
{
	HIDD_ATTRIBUTES	Attributes;
	SP_DEVICE_INTERFACE_DATA devInfoData;
	PSP_DEVICE_INTERFACE_DETAIL_DATA detailData;
	HDEVINFO hDevInfo;
	int	MemberIndex = 0;
	int	DeviceIndex = 0;
	LONG DevInfo;
	ULONG Length = 0;
	ULONG Required;
	GUID HidGuid;

    ZeroMemory(&devInfoData, sizeof(devInfoData));
    devInfoData.cbSize = sizeof(devInfoData);

	HidD_GetHidGuid(&HidGuid);	

	hDevInfo = SetupDiGetClassDevsW(&HidGuid, NULL, NULL, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);

	do{
		DevInfo = SetupDiEnumDeviceInterfaces (hDevInfo, NULL, &HidGuid, MemberIndex, &devInfoData);

		if (DevInfo != 0)
		{
			SetupDiGetDeviceInterfaceDetailW(hDevInfo, &devInfoData, NULL, 0, &Length, NULL);

			detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(Length);
			detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

			SetupDiGetDeviceInterfaceDetailW(hDevInfo, &devInfoData, detailData, Length, &Required, NULL);

			DeviceHandle = CreateFileW(detailData->DevicePath, 0, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_NO_BUFFERING, NULL);

			Attributes.Size = sizeof(Attributes);
			HidD_GetAttributes (DeviceHandle, &Attributes);

			if(Attributes.VendorID == vendorID)
			{
				if((Attributes.ProductID == 0x1113) || (Attributes.ProductID == 0x1114))
				{
					if(Attributes.ProductID == 0x1113) cDevice.SetWindowText(_T("JoyWarrior"));
					if(Attributes.ProductID == 0x1114) cDevice.SetWindowText(_T("MouseWarrior"));

					GetPreparsedData(DeviceHandle);

					GetDlgItem(IDC_WRITEDATA)->EnableWindow(TRUE);
					GetDlgItem(IDC_READDATA)->EnableWindow(TRUE);
					cStatusMsg.SetWindowTextW(_T("Compatible device found"));
					
					cBool = 1;


					HidHandle[DeviceIndex] = CreateFileW(detailData->DevicePath, 
														GENERIC_WRITE | GENERIC_READ, 
														FILE_SHARE_READ|FILE_SHARE_WRITE, 
														NULL,
														OPEN_EXISTING, 
														FILE_FLAG_NO_BUFFERING, 
														NULL);

					
					DeviceIndex++;
					cSerialNo.SetWindowTextW(JwGetSerialNumber(DeviceHandle));
				}
				else
					NULL;
			}
			else
			{
				CloseHandle(DeviceHandle);
			}
		free(detailData);
		}
		MemberIndex++;
	}while (DevInfo != NULL);

	SetupDiDestroyDeviceInfoList(hDevInfo);

	if(cBool != FALSE)
		return 1;
	else
		return 0;
}


/*
Get all dialog-items and create hex-values to write into modul
*/
void CASProgrammerDlg::JwCreateValues(void)
{
	UpdateData(TRUE);

	UCHAR	addr_0B1, addr_0B2, addr_0B3, addr_0B4, addr_0B7;
	UCHAR	addr_111, addr_112, addr_113;
	UCHAR	addr_141, addr_142;
	UCHAR	addr_155;

	/*ADDRESS 14h ->*/
	switch(mRange)
	{
		case 0:
			addr_141 = 0x00;
		break;
		case 1:
			addr_141 = 0x08;
		break;
		case 2:
			addr_141 = 0x10;
		break;
	}

	switch(mBand)
	{
		case 0:
			addr_142 = 0x00;
			break;
		case 1:
			addr_142 = 0x01;
			break;
		case 2:
			addr_142 = 0x02;
			break;
		case 3:
			addr_142 = 0x03;
			break;
		case 4:
			addr_142 = 0x04;
			break;
		case 5:
			addr_142 = 0x05;
			break;
		case 6:
			addr_142 = 0x06;
			break;
	}

	mReg14 = addr_141 | addr_142 | (JwReadData(HidHandle[1], 0x14) & 0xE0);
	/*<- 14h ADDRESS*/


	if(mAdvInt == TRUE) addr_155 = 0x40;
	else addr_155 = 0x00;

	mReg15 = addr_155 | 0x80;
	/*<- 15h ADDRESS*/



	/*ADDRESS 0Bh ->*/
	switch(mCounterHG)
	{
	case 0:
		addr_0B1 = 0x00;
		break;
	case 1:
		addr_0B1 = 0x10;
		break;
	case 2:
		addr_0B1 = 0x20;
		break;
	case 3:
		addr_0B1 = 0x30;
		break;
	}

	if(mEnableHG == TRUE) addr_0B2 = 0x02;
	else addr_0B2 = 0x00;

	switch(mCounterLG)
	{
	case 0:
		addr_0B3 = 0x00;
		break;
	case 1:
		addr_0B3 = 0x04;
		break;
	case 2:
		addr_0B3 = 0x08;
		break;
	case 3:
		addr_0B3 = 0x0C;
		break;
	}

	if(mEnableLG == TRUE) addr_0B4 = 0x01;
	else addr_0B4 = 0x00;

	switch(mAM_AL)
	{
	case 0:
		addr_0B7 = 0x00;
		break;
	case 1:
		addr_0B7 = 0x40;
		break;
	case 2:
		addr_0B7 = 0x80;
		break;
	}


	mReg0B = addr_0B1 | addr_0B2 | addr_0B3 | addr_0B4 | addr_0B7;
	/*<- 0Bh*/


	/*ADDRESS 11h ->*/

	switch(mLGhyst)
	{
		case 0:
			addr_111 = 0x00;
			break;
		case 1:
			addr_111 = 0x01;
			break;
		case 2:
			addr_111 = 0x02;
			break;
		case 3:
			addr_111 = 0x03;
			break;
		case 4:
			addr_111 = 0x04;
			break;
		case 5:
			addr_111 = 0x05;
			break;
		case 6:
			addr_111 = 0x06;
			break;
		case 7:
			addr_111 = 0x07;
			break;
	}

	switch(mHGhyst)
	{
		case 0:
			addr_112 = 0x00;
			break;
		case 1:
			addr_112 = 0x08;
			break;
		case 2:
			addr_112 = 0x10;
			break;
		case 3:
			addr_112 = 0x18;
			break;
		case 4:
			addr_112 = 0x20;
			break;
		case 5:
			addr_112 = 0x28;
			break;
		case 6:
			addr_112 = 0x30;
			break;
		case 7:
			addr_112 = 0x38;
			break;
	}

	switch(mAnyMotion)
	{
		case 0:
			addr_113 = 0x00;
			break;
		case 1:
			addr_113 = 0x40;
			break;
		case 2:
			addr_113 = 0x80;
			break;
		case 3:
			addr_113 = 0xC0;
			break;
	}

	mReg11 = addr_111 | addr_112 | addr_113;
	/*<- 11h*/

	gRegWrite[0] = 0x00; //Register 0x08 -> ReadOnly
	gRegWrite[1] = 0x00; //Register 0x09 -> ReadOnly
	gRegWrite[2] = mReg0B;
	gRegWrite[3] = JwConvertString(mLGthres);
	gRegWrite[4] = JwConvertString(mLGdur);
	gRegWrite[5] = JwConvertString(mHGthres);
	gRegWrite[6] = JwConvertString(mHGdur);
	gRegWrite[7] = JwConvertString(mAMthres);
	gRegWrite[8] = mReg11;
	gRegWrite[9] = JwConvertString(mCust1);
	gRegWrite[10] = JwConvertString(mCust2);
	gRegWrite[11] = mReg14;
	gRegWrite[12] = mReg15;

UpdateData(FALSE);
}

void CASProgrammerDlg::OnBnClickedWritedata()
{
	UCHAR check;
	UCHAR Register[13] = {0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15};

	CString output;

	JwCreateValues();

	UpdateData(TRUE);
	cBool = 2;

	GetDlgItem(IDC_READDATA)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATUSMSG)->SetWindowTextW(_T("Write Register..."));

	switch(mRegister)
	{
	case 0:
		JwWriteData(HidHandle[1], 0x82, 0x0B, mReg0B);
		JwWriteData(HidHandle[1], 0x82, 0x0C, JwConvertString(mLGthres));
		JwWriteData(HidHandle[1], 0x82, 0x0D, JwConvertString(mLGdur));
		JwWriteData(HidHandle[1], 0x82, 0x0E, JwConvertString(mHGthres));
		JwWriteData(HidHandle[1], 0x82, 0x0F, JwConvertString(mHGdur));
		JwWriteData(HidHandle[1], 0x82, 0x10, JwConvertString(mAMthres));
		JwWriteData(HidHandle[1], 0x82, 0x11, mReg11);
		JwWriteData(HidHandle[1], 0x82, 0x12, JwConvertString(mCust1));
		JwWriteData(HidHandle[1], 0x82, 0x13, JwConvertString(mCust2));
		JwWriteData(HidHandle[1], 0x82, 0x14, mReg14);
		JwWriteData(HidHandle[1], 0x82, 0x15, mReg15);
		break;

	case 1:
		JwWriteData(HidHandle[1], 0x82, 0x0A, 0x10);
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x2B, mReg0B);
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x2C, JwConvertString(mLGthres));
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x2D, JwConvertString(mLGdur));
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x2E, JwConvertString(mHGthres));
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x2F, JwConvertString(mHGdur));
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x30, JwConvertString(mAMthres));
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x31, mReg11);
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x32, JwConvertString(mCust1));
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x33, JwConvertString(mCust2));
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x34, mReg14);
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x35, mReg15);
		Sleep(50);
		JwWriteData(HidHandle[1], 0x82, 0x0A, 0x02);
		Sleep(100);
		break;
	}
	memset(&gRegRead, 0, 13);
	GetDlgItem(IDC_READDATA)->EnableWindow(TRUE);

	Sleep(1000);
	GetDlgItem(IDC_STATUSMSG)->SetWindowTextW(_T("Write complete..."));

	Sleep(1000);
	GetDlgItem(IDC_STATUSMSG)->SetWindowTextW(_T("Check register..."));

	for(int i=2;i<13;i++)
	{
		check = JwReadData(HidHandle[1], Register[i]);

		if(check != gRegWrite[i])
		{
			output.Format(_T("0x%.2X"), gRegRead[i]);
			mRepList.SetItemText(i, 2, output);
			mRepList.SetItemText(i, 3, _T("Fault"));
		}
		else
		{
			output.Format(_T("0x%.2X"), gRegWrite[i]);
			mRepList.SetItemText(i, 2, output);
			mRepList.SetItemText(i, 3, _T("OK"));
		}
	}

	Sleep(500);
	GetDlgItem(IDC_STATUSMSG)->SetWindowTextW(_T("Check finished..."));

	cBool = 1;	
	Sleep(500);
	GetDlgItem(IDC_STATUSMSG)->SetWindowTextW(_T("Compatible device found"));

	/*Free Modul for using as Input-Device*/
	JwWriteData(HidHandle[1], 0x02, 0x00, 0x00);

	UpdateData(FALSE);
}

HIDP_CAPS CASProgrammerDlg::GetPreparsedData(HANDLE handle)
{
	PHIDP_PREPARSED_DATA PreparsedData;
	//HIDP_CAPS Capabilities;

	HidD_GetPreparsedData(handle, &PreparsedData);
	HidP_GetCaps(PreparsedData, &Capabilities);
	HidD_FreePreparsedData(PreparsedData);

	return Capabilities;
}


/*
Write-function with USB
*/
BOOL CASProgrammerDlg::JwWriteData(HANDLE handle, UCHAR cmd, UCHAR addr, UCHAR data)
{
	UCHAR			WriteBuffer[10];
	UCHAR			ReadBuffer[10];
	BOOL			Result;
	DWORD			BytesWritten = 0;
	DWORD			NumberOfBytesRead = 0;

	memset(&WriteBuffer, 0, Capabilities.OutputReportByteLength+1);

	WriteBuffer[0] = 0x00;
	WriteBuffer[1] = cmd;
	WriteBuffer[2] = addr;
	WriteBuffer[3] = data;

	Result = WriteFile(handle, &WriteBuffer, Capabilities.OutputReportByteLength, &BytesWritten, NULL);

	if(Result != NULL)
	{
		return 1;
		memset(&ReadBuffer, 0, Capabilities.InputReportByteLength+1);
		ReadBuffer[0] = 0x00;
	
		ReadFile(handle, &ReadBuffer, Capabilities.InputReportByteLength, &NumberOfBytesRead, NULL);
	}
	else
		return 0;
}

/*
Read-function with USB
*/
UCHAR CASProgrammerDlg::JwReadData(HANDLE handle, UCHAR addr)
{
	UCHAR			WriteBuffer[10];
	UCHAR			ReadBuffer[10];
	UCHAR			newAddr;
	DWORD			BytesWritten = 0;
	DWORD			NumberOfBytesRead = 0;
	BOOL			Result;

	HidD_FlushQueue(handle);
	newAddr = 0x80 | addr;

	memset(&WriteBuffer, 0, Capabilities.OutputReportByteLength+1);

	/*Enable command-mode from Jw*/
	WriteBuffer[0] = 0x00; //ReportID
	WriteBuffer[1] = 0x82; //CMD-Mode
	WriteBuffer[2] = newAddr; //CMD + Addr

	Result = WriteFile(handle, &WriteBuffer, Capabilities.OutputReportByteLength, &BytesWritten, NULL);

	if(Result != NULL)
	{
		memset(&ReadBuffer, 0, Capabilities.InputReportByteLength+1);
		ReadBuffer[0] = 0x00;
	
		ReadFile(handle, &ReadBuffer, Capabilities.InputReportByteLength, &NumberOfBytesRead, NULL);
		return ReadBuffer[3];
	}
	else
		return 0;
}


/*
Convert 2-char string from CString into integer
*/
UCHAR CASProgrammerDlg::JwConvertString(CString value)
{
	int	ret, ret1, exec;
	ret = 0;
	ret1 = 0;
	exec = 0;
	char newvalue[2];

	for(int h=0; h<2; h++)
		newvalue[h] = (char) value.GetAt(h);

	switch(newvalue[1])
	{
	case '0':
		ret = 0;
		break;
	case '1':
		ret = 1;
		break;
	case '2':
		ret = 2;
		break;
	case '3':
		ret = 3;
		break;
	case '4':
		ret = 4;
		break;
	case '5':
		ret = 5;
		break;
	case '6':
		ret = 6;
		break;
	case '7':
		ret = 7;
		break;
	case '8':
		ret = 8;
		break;
	case '9':
		ret = 9;
		break;
	case 'A':
		ret = 10;
		break;
	case 'B':
		ret = 11;
		break;
	case 'C':
		ret = 12;
		break;
	case 'D':
		ret = 13;
		break;
	case 'E':
		ret = 14;
		break;
	case 'F':
		ret = 15;
		break;
	}

	switch(newvalue[0])
	{
	case '0':
		ret1 = 0;
		break;
	case '1':
		ret1 = 16;
		break;
	case '2':
		ret1 = 32;
		break;
	case '3':
		ret1 = 48;
		break;
	case '4':
		ret1 = 64;
		break;
	case '5':
		ret1 = 80;
		break;
	case '6':
		ret1 = 96;
		break;
	case '7':
		ret1 = 112;
		break;
	case '8':
		ret1 = 128;
		break;
	case '9':
		ret1 = 144;
		break;
	case 'A':
		ret1 = 160;
		break;
	case 'B':
		ret1 = 176;
		break;
	case 'C':
		ret1 = 192;
		break;
	case 'D':
		ret1 = 208;
		break;
	case 'E':
		ret1 = 224;
		break;
	case 'F':
		ret1 = 240;
		break;
	}

	exec = ret + ret1;

	return exec;
}



void CASProgrammerDlg::OnBnClickedReaddata()
{
	UpdateData(TRUE);
	CString AddReg, Value;
	UCHAR Register[13] = {0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15};
	UCHAR Reg09[6] = {0x80, 0x10, 0x08, 0x04, 0x02, 0x01}; 

	mRepList.DeleteAllItems();
	JwGetRegister(HidHandle[1]);

	for(int i=0; i<13; i++)
	{
		AddReg.Format(_T("0x%.2X"), Register[i]);
		Value.Format(_T("0x%.2X"),  gRegRead[i]); 

		mRepList.InsertItem(i, _T("RD"));
		mRepList.SetItemText(i, 1, AddReg);
		mRepList.SetItemText(i, 2, Value);
	}

	for(int j=0; j<6; j++)
	{
		BitBuffer.DeleteObject();
		
		if((gRegRead[1] & Reg09[j]))
			BitBuffer.LoadBitmapW(IDB_BGREEN);
		else
			BitBuffer.LoadBitmapW(IDB_BGREY);
		
		cBitmap[j].SetBitmap(BitBuffer);
	}

	UpdateData(FALSE);
	JwSetDialog();

	/*Free Modul for using as Input-Device*/
	JwWriteData(HidHandle[1], 0x02, 0x00, 0x00);
}

void CASProgrammerDlg::JwGetRegister(HANDLE handle)
{
	UCHAR Register[13] = {0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15};
	memset(&gRegRead, 0x00, 13);

	for(int i=0; i<13; i++)
		gRegRead[i] = JwReadData(handle, Register[i]); 

	JwWriteData(handle, 0x02, 0x00, 0x00);

	Sleep(100);

	UpdateData(FALSE);
}

/*
Set all dialog-items with the values from jw/mw-modul
*/
void CASProgrammerDlg::JwSetDialog(void)
{
	UpdateData(TRUE);
	UCHAR mask;
	UCHAR Register[13] = {0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15};

	mCust1.Format(_T("%.2X"), gRegRead[9]);
	mCust2.Format(_T("%.2X"), gRegRead[10]);
	mLGthres.Format(_T("%.2X"), gRegRead[3]);
	mLGdur.Format(_T("%.2X"), gRegRead[4]);
	mHGthres.Format(_T("%.2X"), gRegRead[5]);
	mHGdur.Format(_T("%.2X"), gRegRead[6]);
	mAMthres.Format(_T("%.2X"), gRegRead[7]);


	mask = gRegRead[11] & 0x18;
	switch(mask)
	{
	case 0x00:
		mRange = 0;
		break;
	case 0x08:
		mRange = 1;
		break;
	case 0x10:
		mRange = 2;
		break;
	}


	mask = gRegRead[11] & 0x07;
	switch(mask)
	{
	case 0x00:
		mBand = 0;
		break;
	case 0x01:
		mBand = 1;
		break;
	case 0x02:
		mBand = 2;
		break;
	case 0x03:
		mBand = 3;
		break;
	case 0x04:
		mBand = 4;
		break;
	case 0x05:
		mBand = 5;
		break;
	case 0x06:
		mBand = 6;
		break;
	}

	//REGISTER 11h
	mask = gRegRead[8] & 0x07;
	switch(mask)
	{
	case 0x00:
		mLGhyst = 0;
		break;
	case 0x01:
		mLGhyst = 1;
		break;
	case 0x02:
		mLGhyst = 2;
		break;
	case 0x03:
		mLGhyst = 3;
		break;
	case 0x04:
		mLGhyst = 4;
		break;
	case 0x05:
		mLGhyst = 5;
		break;
	case 0x06:
		mLGhyst = 6;
		break;
	case 0x07:
		mLGhyst = 7;
		break;
	}


	mask = gRegRead[8] & 0x38;
	switch(mask)
	{
	case 0x00:
		mHGhyst = 0;
		break;
	case 0x80:
		mHGhyst = 1;
		break;
	case 0x10:
		mHGhyst = 2;
		break;
	case 0x18:
		mHGhyst = 3;
		break;
	case 0x20:
		mHGhyst = 4;
		break;
	case 0x28:
		mHGhyst = 5;
		break;
	case 0x30:
		mHGhyst = 6;
		break;
	case 0x38:
		mHGhyst = 7;
		break;
	}


	mask = gRegRead[8] & 0xC0;
	switch(mask)
	{
	case 0x00:
		mAnyMotion = 0;
		break;
	case 0x40:
		mAnyMotion = 1;
		break;
	case 0x80:
		mAnyMotion = 2;
		break;
	case 0xC0:
		mAnyMotion = 3;
		break;
	}

	// REGISTER 0Bh
	mask = gRegRead[2] & 0x0C;
	switch(mask)
	{
	case 0x00:
		mCounterLG = 0;
		break;
	case 0x04:
		mCounterLG = 1;
		break;
	case 0x08:
		mCounterLG = 2;
		break;
	case 0x0C:
		mCounterLG = 3;
		break;
	}


	mask = gRegRead[2] & 0x30;
	switch(mask)
	{
	case 0x00:
		mCounterHG = 0;
		break;
	case 0x10:
		mCounterHG = 1;
		break;
	case 0x20:
		mCounterHG = 2;
		break;
	case 0x30:
		mCounterHG = 3;
		break;
	}

	mask = gRegRead[2] & 0xC0;
	switch(mask)
	{
	case 0x00:
		mAM_AL = 0;
		break;
	case 0x40:
		mAM_AL = 1;
		break;
	case 0x80:
		mAM_AL = 2;
		break;
	}

	mask = gRegRead[12] & 0x40;
	if(mask == 0x00) mAdvInt = FALSE;
	else if(mask == 0x40) mAdvInt = TRUE;

	mask = gRegRead[2] & 0x01;
	if(mask == 0x00) mEnableLG = FALSE;
	else if(mask == 0x01) mEnableLG = TRUE;

	mask = gRegRead[2] & 0x02;
	if(mask == 0x00) mEnableHG = FALSE;
	else if(mask == 0x02) mEnableHG = TRUE;

	UpdateData(FALSE);
}

void CASProgrammerDlg::OnClose()
{
	CDialog::OnClose();
}

void CASProgrammerDlg::OnDateiExit()
{
	OnOK();
}

void CASProgrammerDlg::OnDateiSave()
{
	CString value;
	CString path;
	CFileDialog cDialog(FALSE, 0, 0, 4|2, _T("Config (*.cfg) |*.cfg||"), 0, 0);

	if(cDialog.DoModal() == IDOK)
	{		
		path.Format(_T("%s.cfg"),cDialog.GetPathName());
		CFile cFile(path, CFile::modeCreate | CFile::modeWrite);
		JwCreateValues();
	
		for(int i=2; i<13; i++)
		{
			value.Format(_T("%.2X\r\n"), gRegWrite[i]);
			cFile.Write((LPCTSTR) value, value.GetLength()*sizeof(TCHAR));
		}
		
		cFile.Close();
	}

}

void CASProgrammerDlg::OnDateiOpen()
{
	CFileDialog cDialog(TRUE, 0, 0, 4|2, _T("Config (*.cfg) |*.cfg||"), 0 ,0);
	CString Buffer, Wert;
	int Index = 2;

	if(cDialog.DoModal() == IDOK)
	{
		CStdioFile File;
		File.Open(cDialog.GetPathName(), CFile::modeRead | CFile::typeBinary);
		File.SeekToBegin();

		while(File.ReadString(Buffer))
		{
			Wert.Format(_T("%s"), Buffer);
			gRegRead[Index] = JwConvertString(Wert);
			Index++;
		}
		File.Close();
		JwSetDialog();
		UpdateData(FALSE);
	}
}


void CASProgrammerDlg::OnFunctiosSoftreset()
{
	JwWriteData(HidHandle[1], 0x82, 0x0A, 0x02);
	Sleep(250);
	OnBnClickedReaddata();
}

void CASProgrammerDlg::OnFunctiosSelftest0()
{
	UCHAR SelfTest;

	if(JwWriteData(HidHandle[1], 0x82, 0x0A, 0x04))
	{
		Sleep(50);
		SelfTest = (JwReadData(HidHandle[1], 0x09) & 0x80);

		if(SelfTest == 0x80)
		{
			if(MessageBox(_T("Selftest successfully"), _T("Proceed Selftest"), MB_OK) == IDOK)
				OnBnClickedReaddata();
		}
		else if(SelfTest != 0x80)
			MessageBox(_T("Selftest failed"), _T("Proceed Selftest"), MB_OK);
	}
	else
		MessageBox(_T("Could not start 'Self_Test_0'.\nPlease check the plugin of JoyWarrior / MouseWarrior."), _T("Malfunction"), MB_OK);

}

/*
Calculate a 10 bit value with MSB and LSB
*/
short CASProgrammerDlg::CalcMsbLsb(UCHAR lsb, UCHAR msb)
{
	short erg;
	short LSB, MSB, EXEC;
	short TEMP = 0x0000;

	EXEC = (msb & 0x80) << 8;
	EXEC = EXEC & 0x8000;

	/*Calcluate nagative value*/
	if(EXEC & 0x8000)
		EXEC = EXEC | 0x7C00;

	MSB = msb << 2;
	MSB = MSB & 0x03FC;
	LSB = (lsb & 0xC0) >> 6;
	LSB = LSB & 0x0003;

	erg = MSB | LSB | EXEC;

	return erg;
}

/*
Check the axis value from X, Y, Z all 50ms
*/
void CASProgrammerDlg::OnTimer(UINT_PTR nIDEvent)
{
	dAxes.GetTimerData(CalcMsbLsb(JwReadData(HidHandle[1], 0x02),JwReadData(HidHandle[1], 0x03)), 'X');
	dAxes.GetTimerData(CalcMsbLsb(JwReadData(HidHandle[1], 0x04),JwReadData(HidHandle[1], 0x05)), 'Y');
	dAxes.GetTimerData(CalcMsbLsb(JwReadData(HidHandle[1], 0x06),JwReadData(HidHandle[1], 0x07)), 'Z');

	CDialog::OnTimer(nIDEvent);
}

/*
Create a dialog witch shows the axis values extra big size
*/
void CASProgrammerDlg::OnFunctionsAxe()
{
	if(HidHandle[1] != NULL)
		SetTimer(IDC_LOOPTIME, 50, NULL);
	else
		KillTimer(IDC_LOOPTIME);
	
	dAxes.cStaticX.SetFont(&cFont, TRUE);
	dAxes.cStaticY.SetFont(&cFont, TRUE);
	dAxes.cStaticZ.SetFont(&cFont, TRUE);

	dAxes.cValueX.SetFont(&cFont, TRUE);
	dAxes.cValueY.SetFont(&cFont, TRUE);
	dAxes.cValueZ.SetFont(&cFont, TRUE);

	dAxes.ShowWindow(SW_SHOW);
}
