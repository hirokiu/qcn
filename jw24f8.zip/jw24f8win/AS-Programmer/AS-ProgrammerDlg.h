// AS-ProgrammerDlg.h : Headerdatei
//

#pragma once

extern "C" { 
#include "hidsdi.h" 
#include "setupapi.h"
#include "Dbt.h"
}



// CAutowriterDlg-Dialogfeld
#include "afxwin.h"
#include "afxcmn.h"
#include "achsendlg.h"


// CASProgrammerDlg-Dialogfeld
class CASProgrammerDlg : public CDialog
{
// Konstruktion
public:
	CASProgrammerDlg(CWnd* pParent = NULL);	// Standardkonstruktor

// Dialogfelddaten
	enum { IDD = IDD_ASPROGRAMMER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung


// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Funktionen f�r die Meldungstabellen
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT JwGetDevice(WPARAM wParam, LPARAM lParam);
	
	
public:
	HANDLE DeviceHandle;
	HANDLE HidHandle[4];
	HIDP_CAPS Capabilities;

	afx_msg void OnBnClickedWritedata();
	afx_msg void OnBnClickedReaddata();
	afx_msg void OnClose();
	afx_msg void OnDateiExit();
	afx_msg void OnDateiSave();
	afx_msg void OnDateiOpen();
	afx_msg void OnFunctiosSoftreset();
	afx_msg void OnFunctiosSelftest0();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

	HIDP_CAPS GetPreparsedData(HANDLE DevHandle);
	void JwGetRegister(HANDLE handle);
	void JwSetDialog(void);
	void JwCreateValues(void);

	CString JwGetSerialNumber(HANDLE handle);

	BOOL JwWriteData(HANDLE handle, UCHAR cmd, UCHAR addr, UCHAR data);
	BOOL JwGetHandle(ULONG productID, ULONG vendorID);

	UCHAR JwReadData(HANDLE handle, UCHAR addr);
	UCHAR JwConvertString(CString value);
	
	int mRange;
	int mBand;
	int mCounterLG;
	int mCounterHG;
	int mAnyMotion;
	int mRegister;
	int mLGhyst;
	int mHGhyst;
	int mAM_AL;
	
	UCHAR gRegRead[13];
	UCHAR gRegWrite[13];
	UCHAR mReg0A;
	UCHAR mReg0B;
	UCHAR mReg11;
	UCHAR mReg14;
	UCHAR mReg15;

	BOOL mBool;
	BOOL mEnableLG;
	BOOL mEnableHG;
	BOOL mAdvInt;
	BOOL cBool;
	BOOL bStatus[6];

	CString Reg_0F;
	CString Reg_0E;
	CString Reg_0D;
	CString Reg_0C;
	CString mCust1;
	CString mCust2;
	CString mLGdur;
	CString mLGthres;
	CString mHGdur;
	CString mHGthres;
	CString mAMthres;
	CListCtrl mRepList;

	CStatic cStatusMsg;
	CStatic cDevice;
	CStatic cSerialNo;

	short CalcMsbLsb(UCHAR lsb, UCHAR msb);
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	CFont cFont;

	CBitmap BitBuffer;
	CStatic cBitmap[6];
	afx_msg void OnFunctionsAxe();
	CAchsenDlg dAxes;
	CMenu cMenu;
};
