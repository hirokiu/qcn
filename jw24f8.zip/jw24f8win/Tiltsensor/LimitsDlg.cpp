// LimitsDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "Neigungswinkel.h"
#include "LimitsDlg.h"


// CLimitsDlg-Dialogfeld

IMPLEMENT_DYNAMIC(CLimitsDlg, CDialog)

CLimitsDlg::CLimitsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLimitsDlg::IDD, pParent)
	, iLimitMinX(256)
	, iLimitMaxX(256)
	, iLimitMinY(256)
	, iLimitMaxY(256)
{

}

CLimitsDlg::~CLimitsDlg()
{
}

void CLimitsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, iLimitMinX);
	DDX_Text(pDX, IDC_EDIT3, iLimitMaxX);
	DDX_Text(pDX, IDC_EDIT2, iLimitMinY);
	DDX_Text(pDX, IDC_EDIT4, iLimitMaxY);
}


BEGIN_MESSAGE_MAP(CLimitsDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &CLimitsDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CLimitsDlg-Meldungshandler

void CLimitsDlg::OnBnClickedButton1()
{
	OnOK();
}
