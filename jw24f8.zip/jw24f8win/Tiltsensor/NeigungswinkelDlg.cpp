// NeigungswinkelDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "Neigungswinkel.h"
#include "NeigungswinkelDlg.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define PI 3.14159265 
#define MW 0x1114
#define JW 0x1113

// CNeigungswinkelDlg-Dialogfeld




CNeigungswinkelDlg::CNeigungswinkelDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNeigungswinkelDlg::IDD, pParent)
	, bStart(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CNeigungswinkelDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ACHSEZ, cAchseZ);
	DDX_Control(pDX, IDC_ACHSEY, cAchseY);
	DDX_Control(pDX, IDC_ACHSEX, cAchseX);
	DDX_Control(pDX, IDC_DEGREE_X, cDegreeX);
	DDX_Control(pDX, IDC_DEGREE_Y, cDegreeY);
	DDX_Control(pDX, IDC_PERCENT_X, cPercentX);
	DDX_Control(pDX, IDC_PERCENT_Y, cPercentY);
	DDX_Control(pDX, IDC_BITMAPCHIP, cBitBuffer);
}

BEGIN_MESSAGE_MAP(CNeigungswinkelDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_CLOSE()
	ON_MESSAGE(WM_DEVICECHANGE, &CNeigungswinkelDlg::GetDevice) //Find devices automaticly
	ON_COMMAND(ID_FUNCIONS_LMITS, &CNeigungswinkelDlg::OnFuncionsLmits)
	ON_COMMAND(ID_FILE_EXIT, &CNeigungswinkelDlg::OnFileExit)
	ON_COMMAND(ID_CONFIGURATION_SAVECONFIG, &CNeigungswinkelDlg::OnConfigurationSaveconfig)
	ON_COMMAND(ID_CONFIGURATION_LOADCONFIG, &CNeigungswinkelDlg::OnConfigurationLoadconfig)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CNeigungswinkelDlg-Meldungshandler

BOOL CNeigungswinkelDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden

	//Set font
	cFont.CreateFont(22, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0, DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, _T("Arial"));

	cAchseX.SetFont(&cFont, TRUE);
	cAchseY.SetFont(&cFont, TRUE);
	cAchseZ.SetFont(&cFont, TRUE);
	cDegreeX.SetFont(&cFont, TRUE);
	cDegreeY.SetFont(&cFont, TRUE);

	GetDlgItem(IDC_STATIC_X)->SetFont(&cFont, TRUE);
	GetDlgItem(IDC_STATIC_Y)->SetFont(&cFont, TRUE);
	GetDlgItem(IDC_STATIC_Z)->SetFont(&cFont, TRUE);

	//Set Handles to "NULL"
	DevHandle[0] = NULL;
	DevHandle[1] = NULL;
	DeviceHandle = NULL;
	bStart = FALSE;

	GetDlgItem(IDC_STATIC_DEVICE)->SetWindowTextW(_T("No compatible device found"));
	GetDlgItem(IDC_STATIC_SERIAL)->SetWindowTextW(_T("- - -"));

	GetHandle(0, 0x07C0);

	if(bStart == TRUE)
		SetTimer(IDC_LOOPTIME, 50, NULL);
	

	return TRUE;
}

void CNeigungswinkelDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CNeigungswinkelDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

HBRUSH CNeigungswinkelDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if(pWnd->GetDlgCtrlID() == IDC_STATIC_DEVICE)
    {
		if(bStart == TRUE)
			pDC->SetTextColor(RGB(0, 160, 0)); //Status GREEN
		else
			pDC->SetTextColor(RGB(160, 0, 0)); //Status RED
    }

	return hbr;
}

LRESULT CNeigungswinkelDlg::GetDevice(WPARAM wParam, LPARAM lParam)
{
	KillTimer(IDC_LOOPTIME);

	//Clear handles
	DevHandle[0] = NULL;
	DevHandle[1] = NULL;
	DeviceHandle = NULL;
	bStart = FALSE;

	GetDlgItem(IDC_STATIC_DEVICE)->SetWindowTextW(_T("No compatible device found"));
	GetDlgItem(IDC_STATIC_SERIAL)->SetWindowTextW(_T("- - -"));

	GetHandle(0, 0x07C0);

	if(bStart == TRUE)
		SetTimer(IDC_LOOPTIME, 50, NULL);
	
	return LRESULT();
}

double CNeigungswinkelDlg::CalcDegree(double value, char axe)
{
	CString msg_degree, msg_percent;
	double winkel;
	double sin;
	double prozent;
	BOOL bLimit = TRUE;
	
	//Check 'axe' and calculate sinus with limit
	switch(axe)
	{
	case 'x':
	case 'X':
		if(value < 0)
			sin = value/dLimits.iLimitMinX;
		else
			sin = value/dLimits.iLimitMaxX;

		if ((value > dLimits.iLimitMaxX) || (value > dLimits.iLimitMinX))
			bLimit = FALSE;
		break;

	case 'y':
	case 'Y':
		if(value < 0)
			sin = value/dLimits.iLimitMinY;
		else
			sin = value/dLimits.iLimitMaxY;

		if ((value > dLimits.iLimitMaxY) || (value > dLimits.iLimitMinY))
			bLimit = FALSE;
		break;

	case 'z':
	case 'Z':
	default:
		break;
	}

	prozent = 100*tan(asin(sin));
	winkel = asin(sin)*180/PI;


	if(bLimit == TRUE)
		msg_degree.Format(_T("%.2f �"), winkel);
	else
		msg_degree.Format(_T("%s"), _T("tilt"));


	if((prozent <= 100) && (prozent >= -100))
		msg_percent.Format(_T("%.1f %s"), prozent, _T("%"));
	else
		msg_percent.Format(_T("--- %s"), _T("%"));

	//Fill dialog-items with values
	switch(axe)
	{
	case 'x':
	case 'X':
		cDegreeX.SetWindowTextW(msg_degree);
		cPercentX.SetWindowTextW(msg_percent);
		SetDialogComp((int)value, 'X');
		break;
	case 'y':
	case 'Y':
		cDegreeY.SetWindowTextW(msg_degree);
		cPercentY.SetWindowTextW(msg_percent);
		SetDialogComp((int)value, 'Y');
		break;
	}

	return 0;
}

BOOL CNeigungswinkelDlg::SetDialogComp(int value, char achse)
{
	CString temp;

	switch(achse)
	{
		case 'X':
		case 'x':
			value = value;
			temp.Format(_T("%.3d"), value);
			cAchseX.SetWindowTextW(temp);
			break;

		case 'Y':
		case 'y':
			value = value;
			temp.Format(_T("%.3d"), value);
			cAchseY.SetWindowTextW(temp);
			break;

		case 'Z':
		case 'z':
			value = value;
			temp.Format(_T("%.3d"), value);
			cAchseZ.SetWindowTextW(temp);

			cBitmap.DeleteObject();
			
			if(value < 0)
				cBitmap.LoadBitmapW(IDB_BITMAP4);
			else
				cBitmap.LoadBitmapW(IDB_BITMAP2);
			
			cBitBuffer.SetBitmap(cBitmap);

			break;

		case 0:
			break;
	}

	return 0;
}

void CNeigungswinkelDlg::OnClose()
{
	if(bStart == TRUE)
	{
		WriteData(0x02, 0x00, 0x00); //Free JW-Modul
		CancelIo(DevHandle[1]);
	}

	CDialog::OnClose();
}

HIDP_CAPS CNeigungswinkelDlg::GetPreparsedData(HANDLE handle)
{
	PHIDP_PREPARSED_DATA PreparsedData;
	//HIDP_CAPS Capabilities;

	HidD_GetPreparsedData(handle, &PreparsedData);
	HidP_GetCaps(PreparsedData, &Capabilities);
	HidD_FreePreparsedData(PreparsedData);

	return Capabilities;
}

void CNeigungswinkelDlg::GetHandle(ULONG pid, ULONG vid)
{
	HIDD_ATTRIBUTES	Attributes;
	SP_DEVICE_INTERFACE_DATA devInfoData;
	PSP_DEVICE_INTERFACE_DETAIL_DATA detailData;
	HDEVINFO hDevInfo;
	int	MemberIndex = 0;
	int	DeviceIndex = 0;
	LONG DevInfo;
	ULONG Length = 0;
	ULONG Required;
	GUID HidGuid;

    ZeroMemory(&devInfoData, sizeof(devInfoData));
    devInfoData.cbSize = sizeof(devInfoData);

	HidD_GetHidGuid(&HidGuid);	

	hDevInfo = SetupDiGetClassDevsW(&HidGuid, NULL, NULL, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);

	do{
		DevInfo = SetupDiEnumDeviceInterfaces (hDevInfo, NULL, &HidGuid, MemberIndex, &devInfoData);

		if (DevInfo != 0)
		{
			SetupDiGetDeviceInterfaceDetailW(hDevInfo, &devInfoData, NULL, 0, &Length, NULL);

			detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(Length);
			detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

			SetupDiGetDeviceInterfaceDetailW(hDevInfo, &devInfoData, detailData, Length, &Required, NULL);

			DeviceHandle = CreateFile (detailData->DevicePath, 0, FILE_SHARE_READ|FILE_SHARE_WRITE, (LPSECURITY_ATTRIBUTES)NULL, OPEN_EXISTING, 0, NULL);

			Attributes.Size = sizeof(Attributes);

			HidD_GetAttributes (DeviceHandle, &Attributes);

			if (Attributes.VendorID == vid) 
			{
				if((Attributes.ProductID == JW) || (Attributes.ProductID == MW))
				{
					if(Attributes.ProductID == JW) GetDlgItem(IDC_STATIC_DEVICE)->SetWindowTextW(_T("JoyWarrior"));
					if(Attributes.ProductID == MW) GetDlgItem(IDC_STATIC_DEVICE)->SetWindowTextW(_T("MouseWarrior"));

					GetPreparsedData(DeviceHandle);

					DevHandle[DeviceIndex] = CreateFileW(detailData->DevicePath, 
														GENERIC_WRITE | GENERIC_READ, 
														FILE_SHARE_READ|FILE_SHARE_WRITE, 
														(LPSECURITY_ATTRIBUTES)NULL, 
														OPEN_EXISTING, 
														0, 
														NULL);

					DeviceIndex++;
					GetDlgItem(IDC_STATIC_SERIAL)->SetWindowTextW(GetSerialNumber(DevHandle[1]));
					bStart = TRUE;
				}
				else
					NULL;
			}
			else
				CloseHandle(DeviceHandle);

			free(detailData);
		}

		MemberIndex++;

	}while (DevInfo != NULL);

	SetupDiDestroyDeviceInfoList(hDevInfo);
}


BOOL CNeigungswinkelDlg::WriteData(UCHAR cmd, UCHAR addr, UCHAR data)
{
	UCHAR			WriteBuffer[10];
	UCHAR			ReadBuffer[10];
	BOOL			Result;
	DWORD			BytesWritten = 0;
	DWORD			NumberOfBytesRead = 0;

	memset(&WriteBuffer, 0, Capabilities.OutputReportByteLength+1);

	WriteBuffer[0] = 0x00;
	WriteBuffer[1] = cmd;
	WriteBuffer[2] = addr;
	WriteBuffer[3] = data;

	Result = WriteFile(DevHandle[1], &WriteBuffer, Capabilities.OutputReportByteLength, &BytesWritten, NULL);

	if(Result != NULL)
	{
		return 1;
		memset(&ReadBuffer, 0, Capabilities.InputReportByteLength+1);
		ReadBuffer[0] = 0x00;
	
		ReadFile(DevHandle[1], &ReadBuffer, Capabilities.InputReportByteLength, &NumberOfBytesRead, NULL);
	}
	else
		return 0;
}

UCHAR CNeigungswinkelDlg::ReadData(HANDLE handle, UCHAR cmd, UCHAR addr)
{
	UCHAR			WriteBuffer[10];
	UCHAR			ReadBuffer[10];
	UCHAR			newAddr;
	DWORD			BytesWritten = 0;
	DWORD			NumberOfBytesRead = 0;
	BOOL			Result;

	newAddr = 0x80 | addr;
	memset(&WriteBuffer, 0, Capabilities.OutputReportByteLength+1);

	WriteBuffer[0] = 0x00;
	WriteBuffer[1] = cmd;
	WriteBuffer[2] = newAddr;

	Result = WriteFile(handle, &WriteBuffer, Capabilities.OutputReportByteLength, &BytesWritten, NULL);

	if(Result != NULL)
	{
		memset(&ReadBuffer, 0, Capabilities.InputReportByteLength+1);
		ReadBuffer[0] = 0x00;
	
		ReadFile(handle, &ReadBuffer, Capabilities.InputReportByteLength, &NumberOfBytesRead, NULL);
		return ReadBuffer[3];
	}
	else
		return 0;
}

void CNeigungswinkelDlg::ReadedData(UCHAR addr_LSB, UCHAR addr_MSB, char axe)
{
	int	iAchse;
	UCHAR MSB, LSB;

	LSB = ReadData(DevHandle[1], 0x82, addr_LSB);
	MSB = ReadData(DevHandle[1], 0x82, addr_MSB);
	iAchse = CalcByte(LSB, MSB);

	SetDialogComp(iAchse, axe);

	if((axe == 'x') || (axe == 'X') || (axe == 'y') ||(axe == 'Y'))
		CalcDegree(iAchse, axe);
}

CString CNeigungswinkelDlg::GetSerialNumber(HANDLE handle)
{
	WCHAR sn[32];
	CString	serial;
	
	memset(&sn, 0, 32);
	HidD_GetSerialNumberString(handle, &sn, 32); 

	serial.Format(_T("%s%s"),serial, &sn[0]);

	return serial;
}

short CNeigungswinkelDlg::CalcByte(UCHAR lsb, UCHAR msb)
{
	short erg;
	short LSB, MSB, EXEC;
	short TEMP = 0x0000;

	EXEC = (msb & 0x80) << 8;
	EXEC = EXEC & 0x8000;

	/*Calculate negative values*/
	if(EXEC & 0x8000)
		EXEC = EXEC | 0x7C00;

	MSB = msb << 2;
	MSB = MSB & 0x03FC;
	LSB = (lsb & 0xC0) >> 6;
	LSB = LSB & 0x0003;

	erg = MSB | LSB | EXEC;

	return erg;
}


void CNeigungswinkelDlg::OnFuncionsLmits()
{
	/*
	The limits are specifically for calulatiing the right degree for each axis.
	Default ar 256 for all sides. You must set the right limits!

	How i do that?

	1. Put the modul into Zero-position (lay flat on the bottom).
	2. Tilt the modul on one side and notice the maximum count (negativ-values for min, positiv-values for max)
	3. Set the limits into the dialog.

	After that you will get the right degree (+/- few degree)
	*/
	dLimits.DoModal();
	UpdateData(FALSE);
}

void CNeigungswinkelDlg::OnFileExit()
{
	if(bStart == TRUE)
	{
		WriteData(0x02, 0x00, 0x00);
		CancelIo(DevHandle[1]);
	}
	OnOK();
}

void CNeigungswinkelDlg::OnConfigurationSaveconfig()
{
	CString value;
	CString path;
	int limits[4];

	limits[0] = dLimits.iLimitMinX;
	limits[1] = dLimits.iLimitMaxX;
	limits[2] = dLimits.iLimitMinY;
	limits[3] = dLimits.iLimitMaxY;

	CFileDialog cDialog(FALSE, 0, 0, 4|2, _T("Config (*.ltd) |*.ltd||"), 0, 0);

	if(cDialog.DoModal() == IDOK)
	{
		path.Format(_T("%s.ltd"),cDialog.GetPathName());
		CFile cFile(path, CFile::modeCreate | CFile::modeWrite);
	
		for(int i=0; i<4; i++)
		{
			value.Format(_T("%d \r\n"), limits[i]);
			cFile.Write((LPCTSTR) value, value.GetLength()*sizeof(TCHAR));
		}
		
		cFile.Close(); 
	}
}

void CNeigungswinkelDlg::OnConfigurationLoadconfig()
{
	CFileDialog cDialog(TRUE, 0, 0, 4|2, _T("Config (*.ltd) |*.ltd||"), 0 ,0);
	CString Buffer;
	int Index = 0;
	int limits[4];

	if(cDialog.DoModal() == IDOK)
	{
		CStdioFile File;
		File.Open(cDialog.GetPathName(), CFile::modeRead | CFile::typeBinary);
		File.SeekToBegin();

		while(File.ReadString(Buffer))
		{
			limits[Index] = _ttoi(Buffer);
			Index++;
		}
		
		File.Close();

		dLimits.iLimitMinX = limits[0];
		dLimits.iLimitMaxX = limits[1];
		dLimits.iLimitMinY = limits[2];
		dLimits.iLimitMaxY = limits[3];

		UpdateData(FALSE);
	}
}

void CNeigungswinkelDlg::OnTimer(UINT_PTR nIDEvent)
{
	ReadedData(0x02, 0x03, 'x');
	ReadedData(0x04, 0x05, 'y');
	ReadedData(0x06, 0x07, 'z');

	CDialog::OnTimer(nIDEvent);
}



