#pragma once


// CLimitsDlg-Dialogfeld

class CLimitsDlg : public CDialog
{
	DECLARE_DYNAMIC(CLimitsDlg)

public:
	CLimitsDlg(CWnd* pParent = NULL);   // Standardkonstruktor
	virtual ~CLimitsDlg();

// Dialogfelddaten
	enum { IDD = IDD_LIMITS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung

	DECLARE_MESSAGE_MAP()
public:
	int iLimitMinX;
	int iLimitMaxX;
	int iLimitMinY;
	int iLimitMaxY;
	afx_msg void OnBnClickedButton1();
};
