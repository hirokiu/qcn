//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Neigungswinkel.rc
//
#define IDC_LOOPTIME                    101
#define IDD_NEIGUNGSWINKEL_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDD_LIMITS                      130
#define IDB_BITMAP1                     131
#define IDB_BITMAP2                     132
#define IDB_BITMAP3                     133
#define IDB_BITMAP4                     135
#define IDC_ACHSEX                      1003
#define IDC_ACHSEY                      1004
#define IDC_ACHSEZ                      1005
#define IDC_DEGREE_X                    1006
#define IDC_ACHSEX_MIN                  1007
#define IDC_PERCENT_X                   1008
#define IDC_DEGREE_Y                    1009
#define IDC_EDIT1                       1009
#define IDC_EDIT2                       1010
#define IDC_PERCENT_Y                   1010
#define IDC_EDIT3                       1011
#define IDC_ACHSEY_MIN                  1012
#define IDC_EDIT4                       1012
#define IDC_ACHSEZ_MIN                  1013
#define IDC_BUTTON1                     1013
#define IDC_STATIC_Z                    1014
#define IDC_EDIT5                       1014
#define IDC_ACHSEX_MAX                  1015
#define IDC_EDIT6                       1015
#define IDC_ACHSEY_MAX                  1016
#define IDC_ACHSEZ_MAX                  1017
#define IDC_STATIC_Y                    1018
#define IDC_STATIC_X                    1019
#define IDC_STATIC_DEVICE               1020
#define IDC_STATIC_SERIAL               1021
#define IDC_BITMAPCHIP                  1022
#define ID_FILE_CONNECT                 32771
#define ID_FILE_EXIT                    32772
#define ID_FUNCIONS_CALIBRATE           32773
#define ID_FUNCIONS_INFORMATIONS        32774
#define ID_FILE_START                   32775
#define ID_FUNCIONS_LMITS               32776
#define ID_FILE_CONFIGURATION           32777
#define ID_CONFIGURATION_SAVECONFIG     32778
#define ID_CONFIGURATION_LOADCONFIG     32779
#define ID_BUTTON32780                  32780
#define ID_BUTTON32781                  32781
#define ID_BUTTON32782                  32782
#define ID_BUTTON32784                  32784
#define ID_BUTTON32785                  32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
