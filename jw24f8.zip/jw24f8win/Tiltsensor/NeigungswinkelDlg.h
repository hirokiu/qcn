// NeigungswinkelDlg.h : Headerdatei
//


#pragma once
#include "afxwin.h"
#include "afxcmn.h"
#include "limitsdlg.h"

extern "C" { 
#include "hidsdi.h" 
#include "setupapi.h"
}

// CNeigungswinkelDlg-Dialogfeld
class CNeigungswinkelDlg : public CDialog
{
// Konstruktion
public:
	CNeigungswinkelDlg(CWnd* pParent = NULL);	// Standardkonstruktor

// Dialogfelddaten
	enum { IDD = IDD_NEIGUNGSWINKEL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung


// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Funktionen f�r die Meldungstabellen
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	LRESULT GetDevice(WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnBnClickedReaddata();
	afx_msg void OnBnClickedConnectdevice();
	afx_msg void OnClose();

	double CalcDegree(double value, char axe);

	BOOL SetDialogComp(int value, char achse);


	HIDP_CAPS							Capabilities;
	HANDLE								DeviceHandle;
	HANDLE								DevHandle[2];

	typedef struct ACHSE {
		int x;
		int y;
		int z;
	} ACHSE;

	typedef struct GRENZWERTE {
		int x[2];
		int y[2];
	} GRENZWERTE;

	//BOOL mBool;

	CStatic cAchseZ;
	CStatic cAchseY;
	CStatic cAchseX;

	CStatic cDegreeX;
	CStatic cDegreeY;

	CStatic cPercentX;
	CStatic cPercentY;


	ACHSE tsMin;
	ACHSE tsMax;

	CLimitsDlg dLimits;
	CFont cFont;
	BOOL bStart;

	void ReadedData(UCHAR addr_LSB, UCHAR addr_MSB, char axe);

	CString GetSerialNumber(HANDLE handle);

	BOOL WriteData(UCHAR cmd, UCHAR addr, UCHAR data);
	UCHAR ReadData(HANDLE handle, UCHAR cmd, UCHAR addr);
	HIDP_CAPS GetPreparsedData(HANDLE handle);

	short CalcByte(UCHAR lsb, UCHAR msb);

	afx_msg void OnFuncionsLmits();
	afx_msg void OnFileExit();
	afx_msg void OnConfigurationSaveconfig();
	afx_msg void OnConfigurationLoadconfig();
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	void GetHandle(ULONG pid, ULONG vid);
	
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	CBitmap cBitmap;
	CStatic cBitBuffer;
};
