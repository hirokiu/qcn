// AutowriterDlg.h : Headerdatei
//

#pragma once

extern "C" { 
#include "hidsdi.h" 
#include "setupapi.h"
}



// CAutowriterDlg-Dialogfeld
#include "afxwin.h"
#include "afxcmn.h"

class CAutowriterDlg : public CDialog
{
// Konstruktion
public:
	CAutowriterDlg(CWnd* pParent = NULL);	// Standardkonstruktor

// Dialogfelddaten
	enum { IDD = IDD_AUTOWRITER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung


// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Funktionen f�r die Meldungstabellen
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT GetDevice(WPARAM wParam, LPARAM lParam);


public:
	HIDP_CAPS							Capabilities;
	HANDLE								DeviceHandle;
	HANDLE								HidHandle[2];

	afx_msg void OnClose();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnFileLoadproject();
	afx_msg void OnOptionsWrite();

	BOOL GetHandle(ULONG productID, ULONG vendorID, int num);
	UCHAR ConvertString(CString value);
	BOOL WriteData(UCHAR cmd, UCHAR addr, UCHAR data);
	UCHAR ReadData(UCHAR addr);
	CString JwGetSerialNumber(HANDLE handle);
	void GetPreparsedData(HANDLE DevHandle);

	CStatic cStatus;
	CStatic cDevice;
	CStatic cCount;
	CStatic cWork;
	CStatic cSerialNum;

	CProgressCtrl cProgress;
	BOOL cBool;
	UCHAR gReadData[11];

	HIDD_ATTRIBUTES GetAttributes(HANDLE handle);
	int gCount;
	CListBox mList;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	BOOL bFile;
	CStatic cProject;
	int iCount;
	afx_msg void OnBnClickedStartprogress();
	BOOL bProgress;
	BOOL bDevice;
	afx_msg void OnFileExit();
};
