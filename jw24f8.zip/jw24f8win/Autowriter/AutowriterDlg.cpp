// AutowriterDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "Autowriter.h"
#include "AutowriterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg-Dialogfeld f�r Anwendungsbefehl "Info"

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialogfelddaten
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung

// Implementierung
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CAutowriterDlg-Dialogfeld




CAutowriterDlg::CAutowriterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAutowriterDlg::IDD, pParent)
	, cBool(FALSE)
	, gCount(0)
	, bFile(FALSE)
	, iCount(0)
	, bProgress(FALSE)
	, bDevice(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAutowriterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATUS, cStatus);
	DDX_Control(pDX, IDC_DEVICE, cDevice);
	DDX_Control(pDX, IDC_CHIPCOUNT, cCount);
	DDX_Control(pDX, IDC_PROGRESS, cProgress);
	DDX_Control(pDX, IDC_WORK, cWork);
	DDX_Control(pDX, IDC_SERIALNUMBER, cSerialNum);
	DDX_Control(pDX, IDC_LIST1, mList);
	DDX_Control(pDX, IDC_PROJECT, cProject);
	DDX_Text(pDX, IDC_CHIPCOUNT, iCount);
	DDX_Check(pDX, IDC_STARTPROGRESS, bProgress);
}

BEGIN_MESSAGE_MAP(CAutowriterDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_DEVICECHANGE, &CAutowriterDlg::GetDevice) //Find devices automaticly
	//}}AFX_MSG_MAP
	ON_WM_CLOSE()
	ON_WM_CTLCOLOR()
	ON_COMMAND(ID_FILE_LOADPROJECT, &CAutowriterDlg::OnFileLoadproject)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_STARTPROGRESS, &CAutowriterDlg::OnBnClickedStartprogress)
	ON_COMMAND(ID_FILE_EXIT, &CAutowriterDlg::OnFileExit)
END_MESSAGE_MAP()



BOOL CAutowriterDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);	
	SetIcon(m_hIcon, FALSE);

	/*Set all CSTATICS to "null"*/
	cDevice.SetWindowTextW(_T("- - - - -"));
	cStatus.SetWindowTextW(_T("No compatible device found"));
	cSerialNum.SetWindowTextW(_T("- - - - -"));
	cProject.SetWindowTextW(_T("- - - - -"));
	cWork.SetWindowTextW(_T("Watiting for load project..."));
	cCount.SetWindowTextW(_T("0"));

	/*Set handles to NULL*/
	HidHandle[0] = NULL;
	HidHandle[1] = NULL;
	bFile = FALSE;

	/*Enumerate all HID-Devices*/
	GetHandle(0, 0x07C0, 0);


	SetTimer(IDC_LOOPTIME, 1000, NULL);

	cProgress.SetRange(0,10);
	cProgress.SetPos(0);
	
	return TRUE;
}

void CAutowriterDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CAutowriterDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext zum Zeichnen

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Symbol in Clientrechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CAutowriterDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CAutowriterDlg::OnClose()
{

	CDialog::OnClose();
}

HBRUSH CAutowriterDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if(pWnd->GetDlgCtrlID() == IDC_STATUS)
    {
		if(bDevice == TRUE)
			pDC->SetTextColor(RGB(0, 128, 0));
		else
			pDC->SetTextColor(RGB(128, 0, 0));
    }


	return hbr;
}




/*
Search every plug-in for HID-Devices
*/
LRESULT CAutowriterDlg::GetDevice(WPARAM wParam, LPARAM lParam)
{
	/*Clear Handles*/
	HidHandle[0] = NULL;
	HidHandle[1] = NULL;
	bDevice = FALSE;

	cWork.SetWindowTextW(_T("Watiting for next device..."));
	cStatus.SetWindowText(_T("No compatible device found"));
	cDevice.SetWindowText(_T("- - - - -"));
	cSerialNum.SetWindowText(_T("- - - - -"));

	GetHandle(0, 0x07C0, 0);

	/*Wait for button*/
	if(bProgress == TRUE)
		SetTimer(IDC_LOOPTIME, 1000, NULL);
	
	return 0;
}


/*
Timer is using for plug-in new HID-Devices (prevent multiple write-opperations)
*/
void CAutowriterDlg::OnTimer(UINT_PTR nIDEvent)
{
	if(bProgress == TRUE) //Button TRUE ?
	{
		if((HidHandle[0] != NULL) || (HidHandle[1] != NULL)) //Handley != 0 ?
		{
			bDevice = TRUE;
			if(bFile == TRUE) //File loaded ?
			{
				KillTimer(IDC_LOOPTIME); //Stop timer
				OnOptionsWrite(); //Start write
			}
		}
		else
		{
			cWork.SetWindowTextW(_T("Watiting for next device..."));
			cStatus.SetWindowText(_T("No compatible device found"));
			cDevice.SetWindowText(_T("- - - - -"));
			cSerialNum.SetWindowText(_T("- - - - -"));

			GetHandle(0, 0x07C0, 0);
		}
	}
	

	CDialog::OnTimer(nIDEvent);
}

/*
Get Serialnumber from device
*/
CString CAutowriterDlg::JwGetSerialNumber(HANDLE handle)
{
	WCHAR sn[32];
	CString	serial;
	
	memset(&sn, 0, 32);
	HidD_GetSerialNumberString(handle, &sn, 32); 

	serial.Format(_T("%s"), &sn[0]);

	return serial;
}

HIDD_ATTRIBUTES CAutowriterDlg::GetAttributes(HANDLE handle)
{
	HIDD_ATTRIBUTES Attributes;

	Attributes.Size = sizeof(Attributes);
	HidD_GetAttributes (handle, &Attributes);
	
	return Attributes;
}

BOOL CAutowriterDlg::GetHandle(ULONG productID, ULONG vendorID, int num)
{
	HIDD_ATTRIBUTES	Attributes;
	SP_DEVICE_INTERFACE_DATA devInfoData;
	PSP_DEVICE_INTERFACE_DETAIL_DATA detailData;
	HDEVINFO hDevInfo;
	int	MemberIndex = 0;
	int	DeviceIndex = 0;
	LONG DevInfo;
	ULONG Length = 0;
	ULONG Required;
	GUID HidGuid;



    ZeroMemory(&devInfoData, sizeof(devInfoData));
    devInfoData.cbSize = sizeof(devInfoData);

	HidD_GetHidGuid(&HidGuid);	

	hDevInfo = SetupDiGetClassDevsW(&HidGuid, NULL, NULL, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);

	do{
		DevInfo = SetupDiEnumDeviceInterfaces (hDevInfo, NULL, &HidGuid, MemberIndex, &devInfoData);

		if (DevInfo != 0)
		{
			SetupDiGetDeviceInterfaceDetail(hDevInfo, &devInfoData, NULL, 0, &Length, NULL);

			detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(Length);
			detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

			SetupDiGetDeviceInterfaceDetail(hDevInfo, &devInfoData, detailData, Length, &Required, NULL);

			DeviceHandle = CreateFileW(detailData->DevicePath, 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);

			Attributes.Size = sizeof(Attributes);
			HidD_GetAttributes (DeviceHandle, &Attributes);

			if (Attributes.VendorID == vendorID)
			{
				if((Attributes.ProductID == 0x1113) || (Attributes.ProductID == 0x1114))
				{
					if(Attributes.ProductID == 0x1113) cDevice.SetWindowText(_T("JoyWarrior"));
					if(Attributes.ProductID == 0x1114) cDevice.SetWindowText(_T("MouseWarrior"));

					cStatus.SetWindowText(_T("Compatible device found"));
					cBool = TRUE;
					
					GetPreparsedData(DeviceHandle);

					HidHandle[DeviceIndex] = CreateFile(detailData->DevicePath, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
					DeviceIndex++;

					bDevice = TRUE;
				}
			}
			else
			{
				CloseHandle(DeviceHandle);
			}
		free(detailData);
		}

		MemberIndex++;

	}while (DevInfo != 0);

	cSerialNum.SetWindowTextW(JwGetSerialNumber(HidHandle[1]));

	SetupDiDestroyDeviceInfoList(hDevInfo);

	if(cBool != FALSE)
		return TRUE;
	else
		return FALSE;
}

void CAutowriterDlg::GetPreparsedData(HANDLE handle)
{
	PHIDP_PREPARSED_DATA PreparsedData;

	HidD_GetPreparsedData(handle, &PreparsedData);
	HidP_GetCaps(PreparsedData, &Capabilities);
	HidD_FreePreparsedData(PreparsedData);
}


/*
Load *.cfg, wich was created with AS-Programmer.
All lines from file will be read and set into "gReadData[]" fo further use
*/
void CAutowriterDlg::OnFileLoadproject()
{
	CFileDialog cDialog(TRUE, 0, 0, 4|2, _T("Config (*.cfg) |*.cfg||"), 0 ,0);
	CString Buffer;
	int Index = 0;

	if(cDialog.DoModal() == IDOK)
	{
		CStdioFile File;
		File.Open(cDialog.GetPathName(), CFile::modeRead | CFile::typeBinary);
		File.SeekToBegin();

		while(File.ReadString(Buffer))
		{
			gReadData[Index] = ConvertString(Buffer);
			Index++;
		}
		
		File.Close();
		cProject.SetWindowTextW(cDialog.GetFileName());

		bFile = TRUE;
		UpdateData(FALSE);
	}
}


/*
Convert CString into a hex-value
*/
UCHAR CAutowriterDlg::ConvertString(CString value)
{
	int	ret, ret1, exec;
	ret = 0;
	ret1 = 0;
	exec = 0;
	char newvalue[2];



	for(int h=0; h<2; h++)
		newvalue[h] = (char) value.GetAt(h);

	switch(newvalue[1])
	{
	case '0':
		ret = 0;
		break;
	case '1':
		ret = 1;
		break;
	case '2':
		ret = 2;
		break;
	case '3':
		ret = 3;
		break;
	case '4':
		ret = 4;
		break;
	case '5':
		ret = 5;
		break;
	case '6':
		ret = 6;
		break;
	case '7':
		ret = 7;
		break;
	case '8':
		ret = 8;
		break;
	case '9':
		ret = 9;
		break;
	case 'A':
		ret = 10;
		break;
	case 'B':
		ret = 11;
		break;
	case 'C':
		ret = 12;
		break;
	case 'D':
		ret = 13;
		break;
	case 'E':
		ret = 14;
		break;
	case 'F':
		ret = 15;
		break;
	}

	switch(newvalue[0])
	{
	case '0':
		ret1 = 0;
		break;
	case '1':
		ret1 = 16;
		break;
	case '2':
		ret1 = 32;
		break;
	case '3':
		ret1 = 48;
		break;
	case '4':
		ret1 = 64;
		break;
	case '5':
		ret1 = 80;
		break;
	case '6':
		ret1 = 96;
		break;
	case '7':
		ret1 = 112;
		break;
	case '8':
		ret1 = 128;
		break;
	case '9':
		ret1 = 144;
		break;
	case 'A':
		ret1 = 160;
		break;
	case 'B':
		ret1 = 176;
		break;
	case 'C':
		ret1 = 192;
		break;
	case 'D':
		ret1 = 208;
		break;
	case 'E':
		ret1 = 224;
		break;
	case 'F':
		ret1 = 240;
		break;
	}

	exec = ret + ret1;

	return exec;
}


/*
Write data from device
*/
BOOL CAutowriterDlg::WriteData(UCHAR cmd, UCHAR addr, UCHAR data)
{
	UCHAR			WriteBuffer[10];
	UCHAR			ReadBuffer[10];
	BOOL			Result;
	DWORD			BytesWritten = 0;
	DWORD			NumberOfBytesRead = 0;

	memset(&WriteBuffer, 0, Capabilities.OutputReportByteLength+1);

	/*Enable command-mode fom Jw/Mw*/
	/*Write Data to SMB380*/
	WriteBuffer[0] = 0x00; //ReportID
	WriteBuffer[1] = cmd; //CMD-Mode
	WriteBuffer[2] = addr; //CMD + Addr
	WriteBuffer[3] = data; //Value

	Result = WriteFile(HidHandle[1], &WriteBuffer, Capabilities.OutputReportByteLength, &BytesWritten, NULL);

	if(Result != NULL)
	{
		return 1;
		memset(&ReadBuffer, 0, Capabilities.InputReportByteLength+1);
		ReadBuffer[0] = 0x00;
	
		ReadFile(HidHandle[1], &ReadBuffer, Capabilities.InputReportByteLength, &NumberOfBytesRead, NULL);
	}
	else
		return 0;
}

/*
Read data from device
*/
UCHAR CAutowriterDlg::ReadData(UCHAR addr)
{
	UCHAR			WriteBuffer[10];
	UCHAR			ReadBuffer[10];
	UCHAR			newAddr;
	DWORD			BytesWritten = 0;
	DWORD			NumberOfBytesRead = 0;
	BOOL			Result;

	HidD_FlushQueue(HidHandle[1]);
	newAddr = 0x80 | addr;

	memset(&WriteBuffer, 0, Capabilities.OutputReportByteLength+1);

	/*Enable command-mode from Jw*/
	WriteBuffer[0] = 0x00; //ReportID
	WriteBuffer[1] = 0x82; //CMD-Mode
	WriteBuffer[2] = newAddr; //CMD + Addr

	Result = WriteFile(HidHandle[1], &WriteBuffer, Capabilities.OutputReportByteLength, &BytesWritten, NULL);

	if(Result != NULL)
	{
		memset(&ReadBuffer, 0, Capabilities.InputReportByteLength+1);
		ReadBuffer[0] = 0x00;
	
		ReadFile(HidHandle[1], &ReadBuffer, Capabilities.InputReportByteLength, &NumberOfBytesRead, NULL);
		return ReadBuffer[3];
	}
	else
		return 0;
}

/*
Start writing to device
*/
void CAutowriterDlg::OnOptionsWrite()
{
	cWork.SetWindowTextW(_T("Programming in progress..."));
	UCHAR Register[11] = {0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15};
	CString list, check;
	int errors = 0;
	UCHAR Read;

	cProgress.SetPos(0);

	WriteData(0x82, 0x0A, 0x10);
	for(int i=0; i<11; i++)
	{
		cProgress.SetPos(i);

		WriteData(0x82, Register[i] | 0x20, gReadData[i]);
		Sleep(50);
	}
	WriteData(0x82, 0x0A, 0x00);

	Sleep(1000);
	cProgress.SetPos(0);

	cWork.SetWindowTextW(_T("Check Register..."));

	for(int j=0; j<11; j++)
	{
		cProgress.SetPos(j);
		Read = ReadData(Register[j]);

		if(Read != gReadData[j])
			errors++;

	}

	if(errors > 0)
		check = _T("Fail");
	else
		check = _T("Ok");

	list.Format(_T("SN: %s   C: %s"), JwGetSerialNumber(HidHandle[1]), check);
	mList.InsertString(0, list);

	iCount++;

	Sleep(1000);

	cWork.SetWindowTextW(_T("Watiting for next device..."));

	UpdateData(FALSE);
}



/*
Set button-text
*/
void CAutowriterDlg::OnBnClickedStartprogress()
{
	UpdateData(TRUE);
	if(bProgress == TRUE)
		GetDlgItem(IDC_STARTPROGRESS)->SetWindowTextW(_T("Stop"));
	else
		GetDlgItem(IDC_STARTPROGRESS)->SetWindowTextW(_T("Start"));
}

void CAutowriterDlg::OnFileExit()
{
	OnOK();
}
